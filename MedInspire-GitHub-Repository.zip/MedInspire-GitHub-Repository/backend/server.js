/**
 * MedInspire Optional Secure HTTPS Backend Service (Node.js / Express)
 *
 * Keeps the AI provider API key (GEMINI_API_KEY) strictly on the server.
 * Endpoint: POST /v1/quotes/generate
 */
const http = require('http');
const https = require('https');

const PORT = process.env.PORT || 8080;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const CLIENT_BEARER_TOKEN = process.env.CLIENT_BEARER_TOKEN || '';

// Basic per-IP rate limiting (max 20 requests per minute per IP)
const ipBuckets = new Map();
function isRateLimited(ip) {
  const now = Date.now();
  const bucket = (ipBuckets.get(ip) || []).filter(ts => now - ts < 60000);
  if (bucket.length >= 20) return true;
  bucket.push(now);
  ipBuckets.set(ip, bucket);
  return false;
}

function validateGeneratedQuote(raw) {
  if (!raw || typeof raw !== 'string') return null;
  const cleaned = raw.replace(/^["'“”‘’*\s]+|["'“”‘’*\s]+$/g, '').replace(/\s+/g, ' ').trim();
  const words = cleaned.split(' ').filter(Boolean);
  if (words.length < 6 || words.length > 34) return null;
  if (/(hippocrates|osler|gawande|kalanithi|charaka|sushruta)/i.test(cleaned)) return null;
  return cleaned;
}

async function callGeminiProvider(promptText) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: promptText }] }],
      generationConfig: { temperature: 0.85, maxOutputTokens: 80 }
    })
  });
  if (!response.ok) throw new Error(`Upstream HTTP ${response.status}`);
  const data = await response.json();
  return data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200);
    return res.end(JSON.stringify({ status: 'ok', service: 'medinspire-ai-backend' }));
  }
  if (req.method !== 'POST' || req.url !== '/v1/quotes/generate') {
    res.writeHead(404);
    return res.end(JSON.stringify({ error: 'Not found' }));
  }

  const clientIp = req.socket.remoteAddress || 'unknown';
  if (isRateLimited(clientIp)) {
    res.writeHead(429);
    return res.end(JSON.stringify({ error: 'Rate limit exceeded. Try again in a minute.' }));
  }

  if (CLIENT_BEARER_TOKEN) {
    const auth = req.headers['authorization'] || '';
    if (auth !== `Bearer ${CLIENT_BEARER_TOKEN}`) {
      res.writeHead(401);
      return res.end(JSON.stringify({ error: 'Unauthorized client token' }));
    }
  }

  let body = '';
  req.on('data', chunk => {
    body += chunk;
    if (body.length > 16384) req.destroy();
  });

  req.on('end', async () => {
    try {
      const payload = JSON.parse(body || '{}');
      const categoryName = String(payload.categoryName || 'MBBS Motivation').slice(0, 80);
      const specialty = String(payload.specialty || 'Clinical Medicine').slice(0, 80);
      const emotionalTone = String(payload.emotionalTone || 'calm and resolute').slice(0, 60);
      const writingStyle = String(payload.writingStyle || 'clinical aphorism').slice(0, 80);

      if (!GEMINI_API_KEY) {
        res.writeHead(503);
        return res.end(JSON.stringify({ error: 'GEMINI_API_KEY not configured on server' }));
      }

      const prompt = [
        'You are MedInspire, writing a single original motivational quote for an MBBS student or resident doctor.',
        `Category: ${categoryName} (${specialty}).`,
        `Tone: ${emotionalTone}. Style: ${writingStyle}.`,
        'Length: strictly 8 to 24 words.',
        'Rules: Output ONLY the quote sentence. No quotation marks, no author names, no famous doctor attributions, no cliches.'
      ].join(' ');

      const rawText = await callGeminiProvider(prompt);
      const validQuote = validateGeneratedQuote(rawText);
      if (!validQuote) {
        res.writeHead(422);
        return res.end(JSON.stringify({ error: 'Generated quote did not pass validation' }));
      }

      res.writeHead(200);
      return res.end(JSON.stringify({
        quote: validQuote,
        categoryName,
        attribution: 'MedInspire Original',
        sourceMode: 'AI_ONLINE'
      }));
    } catch (err) {
      res.writeHead(500);
      return res.end(JSON.stringify({ error: 'Quote generation failed' }));
    }
  });
});

if (require.main === module) {
  server.listen(PORT, () => {
    console.log(`MedInspire AI Backend listening on port ${PORT}`);
  });
}

module.exports = { server, validateGeneratedQuote };
