## Summary of Changes

- [ ] Tested on `2×2`, `4×2`, and `4×3` home-screen widget layouts
- [ ] Passed `QuoteValidatorAndUniquenessTest` unit tests
- [ ] Verified zero hardcoded API keys or secrets
