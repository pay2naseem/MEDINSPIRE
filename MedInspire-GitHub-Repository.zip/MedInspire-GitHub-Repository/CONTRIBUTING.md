# Contributing to MedInspire

Thank you for helping improve **MedInspire — Medical Motivation Widget** for MBBS students and clinicians!

## Development Workflow

1. **Fork & Clone** the repository:
   ```bash
   git clone https://github.com/<your-username>/MedInspire.git
   cd MedInspire
   ```
2. **Run Unit Tests**:
   ```bash
   ./gradlew testDebugUnitTest
   ```
3. **Build Debug APK**:
   ```bash
   ./gradlew assembleDebug
   ```
4. **Quote Quality Guidelines**:
   - Quotes must be original, thoughtful, and between **8 and 25 words** (up to 35 words for `4×3` widgets).
   - Never attribute AI or original quotes to historical physicians or authors.
   - Ensure all additions pass `QuoteValidatorAndUniquenessTest`.
