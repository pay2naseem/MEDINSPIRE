package com.medinspire.app

import com.medinspire.app.data.offline.OfflineQuoteEngine
import com.medinspire.app.domain.model.QuoteCategory
import com.medinspire.app.domain.validation.QuoteValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class QuoteValidatorAndUniquenessTest {

    @Test
    fun `normalizeText strips punctuation case and extra whitespace`() {
        val a = "  “Every page you master TODAY, becomes part of the care you offer tomorrow!” "
        val b = "every page you master today becomes part of the care you offer tomorrow"
        assertEquals(QuoteValidator.normalizeText(a), QuoteValidator.normalizeText(b))
        assertEquals(QuoteValidator.computeNormalizedHash(a), QuoteValidator.computeNormalizedHash(b))
    }

    @Test
    fun `validateStructure accepts valid medical motivational quote`() {
        val quote = "Clinical competence is built quietly in the hours when nobody is applauding your discipline."
        val res = QuoteValidator.validateStructure(quote)
        assertTrue(res.isValid)
        assertTrue(res.normalizedHash.length == 64)
    }

    @Test
    fun `validateStructure rejects too short or too long quotes`() {
        val tooShort = "Study hard every day."
        assertFalse(QuoteValidator.validateStructure(tooShort).isValid)

        val tooLong = (1..35).joinToString(" ") { "word$it" }
        assertFalse(QuoteValidator.validateStructure(tooLong, allowExtendedLength = false).isValid)
        assertTrue(QuoteValidator.validateStructure(tooLong, allowExtendedLength = true).isValid)
    }

    @Test
    fun `validateStructure rejects false doctor or author attributions`() {
        val oslerQuote = "The good physician treats the disease; the great physician treats the patient. — Sir William Osler"
        val res = QuoteValidator.validateStructure(oslerQuote)
        assertFalse(res.isValid)
    }

    @Test
    fun `isDuplicateOrTooSimilar detects exact and near-duplicate quotes`() {
        val existing = "Every nerve course you trace in the dissection hall prevents hesitation in a future surgical field."
        val existingHash = QuoteValidator.computeNormalizedHash(existing)

        // Exact match with different casing/punctuation
        assertTrue(
            QuoteValidator.isDuplicateOrTooSimilar(
                "every nerve course you trace in the dissection hall, prevents hesitation in a future surgical field!",
                setOf(existingHash),
                listOf(existing)
            )
        )

        // Near duplicate (1 word changed)
        val nearDuplicate = "Every nerve pathway you trace in the dissection hall prevents hesitation in a future surgical field."
        assertTrue(
            QuoteValidator.isDuplicateOrTooSimilar(
                nearDuplicate,
                setOf(existingHash),
                listOf(existing)
            )
        )

        // Completely distinct medical quote
        val distinct = "Pharmacokinetics is clinical stewardship: the right molecule, at the right receptor, with minimal harm."
        assertFalse(
            QuoteValidator.isDuplicateOrTooSimilar(
                distinct,
                setOf(existingHash),
                listOf(existing)
            )
        )
    }

    @Test
    fun `offlineQuoteEngine generates 80 consecutive unique valid quotes without repeats`() {
        val hashes = mutableSetOf<String>()
        val texts = mutableListOf<String>()

        for (i in 1..80) {
            val generated = OfflineQuoteEngine.generateUniqueOfflineQuote(
                preferredCategories = QuoteCategory.entries.toSet(),
                existingHashes = hashes,
                recentQuoteTexts = texts
            )
            val validation = QuoteValidator.validateStructure(generated.text)
            assertTrue("Quote #$i failed validation: ${generated.text}", validation.isValid)
            assertFalse("Quote #$i was a duplicate hash", hashes.contains(generated.normalizedHash))
            hashes.add(generated.normalizedHash)
            texts.add(generated.text)
        }
        assertEquals(80, hashes.size)
    }
}
