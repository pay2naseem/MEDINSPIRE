package com.medinspire.app.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.medinspire.app.domain.model.QuoteCategory
import com.medinspire.app.domain.model.QuoteTextSize
import com.medinspire.app.domain.model.WidgetThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "medinspire_settings")

data class UserSettings(
    val selectedCategories: Set<QuoteCategory> = QuoteCategory.entries.toSet(),
    val themeMode: WidgetThemeMode = WidgetThemeMode.DARK_NAVY,
    val quoteTextSize: QuoteTextSize = QuoteTextSize.STANDARD,
    val showAttributionOnWidget: Boolean = true,
    val tapQuoteToRefresh: Boolean = true,
    val periodicRefreshHours: Int = 6,
    val aiEndpointUrl: String = "",
    val aiClientToken: String = "",
    val forceOfflineMode: Boolean = false
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val SELECTED_CATEGORIES = stringSetPreferencesKey("selected_categories")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val TEXT_SIZE = stringPreferencesKey("quote_text_size")
        val SHOW_ATTRIBUTION = booleanPreferencesKey("show_attribution_on_widget")
        val TAP_QUOTE_TO_REFRESH = booleanPreferencesKey("tap_quote_to_refresh")
        val PERIODIC_REFRESH_HOURS = intPreferencesKey("periodic_refresh_hours")
        val AI_ENDPOINT_URL = stringPreferencesKey("ai_endpoint_url")
        val AI_CLIENT_TOKEN = stringPreferencesKey("ai_client_token")
        val FORCE_OFFLINE_MODE = booleanPreferencesKey("force_offline_mode")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        val rawCats = prefs[Keys.SELECTED_CATEGORIES]
        val categories = if (rawCats.isNullOrEmpty()) {
            QuoteCategory.entries.toSet()
        } else {
            rawCats.map { QuoteCategory.fromId(it) }.toSet()
        }

        val theme = WidgetThemeMode.entries.firstOrNull {
            it.id == prefs[Keys.THEME_MODE]
        } ?: WidgetThemeMode.DARK_NAVY

        val textSize = QuoteTextSize.entries.firstOrNull {
            it.id == prefs[Keys.TEXT_SIZE]
        } ?: QuoteTextSize.STANDARD

        UserSettings(
            selectedCategories = categories,
            themeMode = theme,
            quoteTextSize = textSize,
            showAttributionOnWidget = prefs[Keys.SHOW_ATTRIBUTION] ?: true,
            tapQuoteToRefresh = prefs[Keys.TAP_QUOTE_TO_REFRESH] ?: true,
            periodicRefreshHours = prefs[Keys.PERIODIC_REFRESH_HOURS] ?: 6,
            aiEndpointUrl = prefs[Keys.AI_ENDPOINT_URL] ?: "",
            aiClientToken = prefs[Keys.AI_CLIENT_TOKEN] ?: "",
            forceOfflineMode = prefs[Keys.FORCE_OFFLINE_MODE] ?: false
        )
    }

    suspend fun toggleCategory(category: QuoteCategory) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.SELECTED_CATEGORIES]
                ?.map { QuoteCategory.fromId(it) }
                ?.toMutableSet()
                ?: QuoteCategory.entries.toMutableSet()

            if (current.contains(category)) {
                if (current.size > 1) current.remove(category)
            } else {
                current.add(category)
            }
            prefs[Keys.SELECTED_CATEGORIES] = current.map { it.id }.toSet()
        }
    }

    suspend fun updateThemeMode(mode: WidgetThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.id }
    }

    suspend fun updateTextSize(size: QuoteTextSize) {
        context.dataStore.edit { it[Keys.TEXT_SIZE] = size.id }
    }

    suspend fun updateWidgetOptions(showAttribution: Boolean, tapToRefresh: Boolean, refreshHours: Int) {
        context.dataStore.edit {
            it[Keys.SHOW_ATTRIBUTION] = showAttribution
            it[Keys.TAP_QUOTE_TO_REFRESH] = tapToRefresh
            it[Keys.PERIODIC_REFRESH_HOURS] = refreshHours
        }
    }

    suspend fun updateAiConfiguration(endpointUrl: String, clientToken: String, forceOffline: Boolean) {
        context.dataStore.edit {
            it[Keys.AI_ENDPOINT_URL] = endpointUrl.trim()
            it[Keys.AI_CLIENT_TOKEN] = clientToken.trim()
            it[Keys.FORCE_OFFLINE_MODE] = forceOffline
        }
    }
}
