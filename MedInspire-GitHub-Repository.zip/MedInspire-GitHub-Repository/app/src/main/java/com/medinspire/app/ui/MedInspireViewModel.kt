package com.medinspire.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.medinspire.app.data.preferences.UserPreferencesRepository
import com.medinspire.app.data.preferences.UserSettings
import com.medinspire.app.data.repository.QuoteRepository
import com.medinspire.app.domain.model.Quote
import com.medinspire.app.domain.model.QuoteCategory
import com.medinspire.app.domain.model.QuoteTextSize
import com.medinspire.app.domain.model.WidgetThemeMode
import com.medinspire.app.widget.MedInspireWidgetProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MedInspireViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = QuoteRepository(application)
    private val preferencesRepository = UserPreferencesRepository(application)

    val currentQuote: StateFlow<Quote?> = repository.observeLatestQuote()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val favorites: StateFlow<List<Quote>> = repository.observeFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<Quote>> = repository.observeHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<UserSettings> = preferencesRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getOrEnsureCurrentQuote()
            MedInspireWidgetProvider.updateAllWidgets(getApplication(), isLoading = false)
        }
    }

    fun requestNewQuote() {
        if (_isGenerating.value) return
        viewModelScope.launch {
            _isGenerating.value = true
            MedInspireWidgetProvider.updateAllWidgets(getApplication(), isLoading = true)
            try {
                repository.generateAndSaveNextQuote(allowExtendedLength = false)
            } finally {
                _isGenerating.value = false
                MedInspireWidgetProvider.updateAllWidgets(getApplication(), isLoading = false)
            }
        }
    }

    fun toggleFavorite(quote: Quote) {
        viewModelScope.launch {
            repository.toggleFavorite(quote)
        }
    }

    fun toggleCategory(category: QuoteCategory) {
        viewModelScope.launch {
            preferencesRepository.toggleCategory(category)
        }
    }

    fun updateTheme(mode: WidgetThemeMode) {
        viewModelScope.launch {
            preferencesRepository.updateThemeMode(mode)
            MedInspireWidgetProvider.updateAllWidgets(getApplication(), isLoading = false)
        }
    }

    fun updateTextSize(size: QuoteTextSize) {
        viewModelScope.launch {
            preferencesRepository.updateTextSize(size)
            MedInspireWidgetProvider.updateAllWidgets(getApplication(), isLoading = false)
        }
    }

    fun updateWidgetOptions(showAttribution: Boolean, tapToRefresh: Boolean, refreshHours: Int) {
        viewModelScope.launch {
            preferencesRepository.updateWidgetOptions(showAttribution, tapToRefresh, refreshHours)
            MedInspireWidgetProvider.updateAllWidgets(getApplication(), isLoading = false)
        }
    }

    fun updateAiConfig(endpointUrl: String, clientToken: String, forceOffline: Boolean) {
        viewModelScope.launch {
            preferencesRepository.updateAiConfiguration(endpointUrl, clientToken, forceOffline)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }
}
