package com.medinspire.app.widget

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.medinspire.app.data.repository.QuoteRepository
import java.util.concurrent.TimeUnit

/**
 * Battery-respectful background worker using Android WorkManager to refresh
 * the home-screen widget quote periodically without holding a permanent service.
 */
class WidgetRefreshWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val repo = QuoteRepository(applicationContext)
            repo.generateAndSaveNextQuote(allowExtendedLength = false)
            MedInspireWidgetProvider.updateAllWidgets(applicationContext, isLoading = false)
            Result.success()
        } catch (e: Exception) {
            // Never erase a valid quote if background refresh fails
            MedInspireWidgetProvider.updateAllWidgets(applicationContext, isLoading = false)
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "medinspire_periodic_widget_refresh"

        fun enqueuePeriodicWork(context: Context, intervalHours: Long = 6L) {
            val safeHours = intervalHours.coerceAtLeast(1L)
            val request = PeriodicWorkRequestBuilder<WidgetRefreshWorker>(
                safeHours,
                TimeUnit.HOURS
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
