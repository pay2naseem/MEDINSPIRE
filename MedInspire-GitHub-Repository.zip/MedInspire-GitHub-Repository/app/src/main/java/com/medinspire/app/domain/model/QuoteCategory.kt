package com.medinspire.app.domain.model

enum class QuoteCategory(
    val id: String,
    val displayName: String,
    val shortBadge: String,
    val specialties: List<String>,
    val description: String
) {
    MBBS_MOTIVATION(
        id = "mbbs_motivation",
        displayName = "MBBS Motivation",
        shortBadge = "MBBS Life",
        specialties = listOf("General Medicine", "Medical School Foundation", "Pre-Clinical & Para-Clinical"),
        description = "Daily purpose and perspective across the MBBS journey."
    ),
    ANATOMY_PHYSIOLOGY(
        id = "anatomy_physiology",
        displayName = "Anatomy and Physiology",
        shortBadge = "Anatomy & Physio",
        specialties = listOf("Gross Anatomy", "Neuroanatomy", "Cardiovascular Physiology", "Renal Homeostasis"),
        description = "Dissection hall patience, physiological mechanisms, and structural mastery."
    ),
    PATHOLOGY_PHARMACOLOGY(
        id = "pathology_pharmacology",
        displayName = "Pathology and Pharmacology",
        shortBadge = "Path & Pharm",
        specialties = listOf("Systemic Pathology", "Histopathology", "Clinical Pharmacology", "Microbiology"),
        description = "Understanding disease mechanisms and rational therapeutics."
    ),
    CLINICAL_ROTATIONS(
        id = "clinical_rotations",
        displayName = "Clinical Rotations",
        shortBadge = "Clinical Postings",
        specialties = listOf("Internal Medicine Ward", "General Surgery", "Pediatrics", "Obstetrics & Gynecology", "Emergency Triage"),
        description = "Bedside history taking, physical signs, ward rounds, and clinical acumen."
    ),
    VIVA_EXAMS(
        id = "viva_exams",
        displayName = "Viva and University Exams",
        shortBadge = "Viva & Profs",
        specialties = listOf("OSCE / Practical Viva", "University Theory Finals", "Long Case Presentation"),
        description = "Composure under examination pressure and structured recall."
    ),
    NEET_PG_INI_CET(
        id = "neet_pg_ini_cet",
        displayName = "NEET-PG and INI-CET",
        shortBadge = "NEET-PG / INI-CET",
        specialties = listOf("Grand Tests", "High-Yield Revision", "Clinical Vignette Analysis", "Residency Entrance"),
        description = "Endurance for competitive postgraduate medical entrance preparation."
    ),
    DISCIPLINE_CONSISTENCY(
        id = "discipline_consistency",
        displayName = "Discipline and Consistency",
        shortBadge = "Discipline",
        specialties = listOf("Late-Night Study", "Spaced Repetition", "Daily Clinical Habit"),
        description = "Quiet, unglamorous repetition that compounds into medical competence."
    ),
    FAILURE_COMEBACKS(
        id = "failure_comebacks",
        displayName = "Failure and Comebacks",
        shortBadge = "Resilience",
        specialties = listOf("Academic Recovery", "Missed Diagnosis Learning", "Post-Exam Rebuild"),
        description = "Turning tough viva rounds, low mock scores, and fatigue into growth."
    ),
    BECOMING_A_DOCTOR(
        id = "becoming_a_doctor",
        displayName = "Becoming a Doctor",
        shortBadge = "White Coat Journey",
        specialties = listOf("Internship Transition", "First Night Duty", "Clinical Responsibility"),
        description = "Evolving from an anxious student into a steady, trustworthy clinician."
    ),
    PATIENT_CARE_COMPASSION(
        id = "patient_care_compassion",
        displayName = "Patient Care and Compassion",
        shortBadge = "Patient Care",
        specialties = listOf("Bedside Empathy", "Medical Ethics", "Palliative & Acute Care"),
        description = "Remembering the human heartbeat behind every chart and lab report."
    );

    companion object {
        fun fromId(id: String?): QuoteCategory {
            if (id.isNullOrBlank()) return MBBS_MOTIVATION
            return entries.firstOrNull {
                it.id.equals(id, ignoreCase = true) || it.displayName.equals(id, ignoreCase = true)
            } ?: MBBS_MOTIVATION
        }
    }
}
