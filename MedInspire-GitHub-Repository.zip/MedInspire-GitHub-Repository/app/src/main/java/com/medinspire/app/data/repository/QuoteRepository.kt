package com.medinspire.app.data.repository

import android.content.Context
import com.medinspire.app.data.local.MedInspireDatabase
import com.medinspire.app.data.local.QuoteEntity
import com.medinspire.app.data.offline.OfflineQuoteEngine
import com.medinspire.app.data.preferences.UserPreferencesRepository
import com.medinspire.app.data.remote.AiQuoteService
import com.medinspire.app.domain.model.Quote
import com.medinspire.app.domain.model.QuoteCategory
import com.medinspire.app.domain.model.QuoteSourceMode
import com.medinspire.app.domain.validation.QuoteValidator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class QuoteRepository(
    context: Context,
    private val database: MedInspireDatabase = MedInspireDatabase.getInstance(context),
    private val preferencesRepository: UserPreferencesRepository = UserPreferencesRepository(context),
    private val aiQuoteService: AiQuoteService = AiQuoteService()
) {
    private val quoteDao = database.quoteDao()
    private val generationMutex = Mutex()

    @Volatile
    private var lastGenerationMillis: Long = 0L

    companion object {
        private const val MIN_REFRESH_DEBOUNCE_MS = 1200L
        private const val MAX_AI_ATTEMPTS = 3
        private const val MAX_HISTORY_RETAINED = 400
    }

    fun observeLatestQuote(): Flow<Quote?> =
        quoteDao.observeLatestQuote().map { it?.toDomain() }

    fun observeHistory(): Flow<List<Quote>> =
        quoteDao.observeHistory().map { list -> list.map { it.toDomain() } }

    fun observeFavorites(): Flow<List<Quote>> =
        quoteDao.observeFavorites().map { list -> list.map { it.toDomain() } }

    suspend fun getOrEnsureCurrentQuote(): Quote {
        val existing = quoteDao.getLatestQuote()?.toDomain()
        if (existing != null) return existing
        return generateAndSaveNextQuote(allowExtendedLength = false, bypassDebounce = true)
    }

    /**
     * Requests a fresh quote:
     * 1. Checks debounce lock so rapid taps do not spam requests.
     * 2. If an HTTPS AI backend is configured and offline mode is not forced, tries up to
     *    MAX_AI_ATTEMPTS with randomized category/specialty/tone/style, validating structure
     *    and rejecting exact/similar duplicates against local Room history.
     * 3. If offline or AI fails/returns duplicates, seamlessly falls back to the local
     *    Compositional & Curated Offline Quote Engine and labels the quote accurately as OFFLINE_ENGINE.
     * 4. Saves to Room and prunes excess non-favorite history.
     */
    suspend fun generateAndSaveNextQuote(
        allowExtendedLength: Boolean = false,
        bypassDebounce: Boolean = false
    ): Quote = generationMutex.withLock {
        val now = System.currentTimeMillis()
        if (!bypassDebounce && (now - lastGenerationMillis) < MIN_REFRESH_DEBOUNCE_MS) {
            quoteDao.getLatestQuote()?.toDomain()?.let { return@withLock it }
        }
        lastGenerationMillis = now

        val settings = preferencesRepository.settingsFlow.first()
        val existingHashes = quoteDao.getAllNormalizedHashes().toSet()
        val recentTexts = quoteDao.getRecentQuoteTexts(limit = 150)

        // Try Live HTTPS AI generation when configured and enabled
        if (!settings.forceOfflineMode && settings.aiEndpointUrl.isNotBlank()) {
            for (attempt in 1..MAX_AI_ATTEMPTS) {
                val payload = aiQuoteService.buildRandomizedPayload(
                    categories = settings.selectedCategories,
                    recentHashes = existingHashes.take(25),
                    allowExtendedLength = allowExtendedLength,
                    attemptNumber = attempt
                )
                when (val result = aiQuoteService.requestQuoteFromBackend(
                    endpointUrl = settings.aiEndpointUrl,
                    clientToken = settings.aiClientToken,
                    payload = payload
                )) {
                    is AiQuoteService.AiResult.Success -> {
                        val validation = QuoteValidator.validateStructure(
                            rawText = result.quoteText,
                            allowExtendedLength = allowExtendedLength
                        )
                        if (validation.isValid && !QuoteValidator.isDuplicateOrTooSimilar(
                                validation.cleanedText,
                                existingHashes,
                                recentTexts
                            )
                        ) {
                            return@withLock persistQuote(
                                text = validation.cleanedText,
                                category = result.category,
                                sourceMode = QuoteSourceMode.AI_ONLINE,
                                normalizedHash = validation.normalizedHash
                            )
                        }
                    }
                    is AiQuoteService.AiResult.Failure -> {
                        // Break early on network/endpoint failure and fall back to offline engine
                        break
                    }
                }
            }
        }

        // Honest Offline Fallback Generation
        val offlineGenerated = OfflineQuoteEngine.generateUniqueOfflineQuote(
            preferredCategories = settings.selectedCategories,
            existingHashes = existingHashes,
            recentQuoteTexts = recentTexts,
            allowExtendedLength = allowExtendedLength
        )

        return@withLock persistQuote(
            text = offlineGenerated.text,
            category = offlineGenerated.category,
            sourceMode = QuoteSourceMode.OFFLINE_ENGINE,
            normalizedHash = offlineGenerated.normalizedHash
        )
    }

    private suspend fun persistQuote(
        text: String,
        category: QuoteCategory,
        sourceMode: QuoteSourceMode,
        normalizedHash: String
    ): Quote {
        val now = System.currentTimeMillis()
        val entity = QuoteEntity(
            text = text,
            categoryId = category.id,
            sourceMode = sourceMode.name,
            attribution = "MedInspire Original",
            createdAtMillis = now,
            isFavorite = false,
            normalizedHash = normalizedHash
        )
        return try {
            val id = quoteDao.insertQuote(entity)
            quoteDao.pruneOldHistory(MAX_HISTORY_RETAINED)
            entity.copy(id = id).toDomain()
        } catch (e: Exception) {
            // If hash collision occurs after full corpus exhaustion, return latest valid quote
            quoteDao.getLatestQuote()?.toDomain() ?: entity.toDomain()
        }
    }

    suspend fun toggleFavorite(quote: Quote) {
        quoteDao.setFavorite(quote.id, !quote.isFavorite)
    }

    suspend fun clearHistory() {
        quoteDao.clearNonFavoriteHistory()
    }
}
