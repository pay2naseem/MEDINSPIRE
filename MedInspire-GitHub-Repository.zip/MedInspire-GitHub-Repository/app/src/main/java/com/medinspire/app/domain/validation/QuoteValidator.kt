package com.medinspire.app.domain.validation

import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.min

/**
 * Validates AI and offline motivational quotes for length, originality, absence of
 * false celebrity/physician attributions, normalized hash uniqueness, and
 * Jaccard / Levenshtein similarity thresholds.
 */
object QuoteValidator {

    const val MIN_WORDS = 6
    const val MAX_WORDS_STANDARD = 28
    const val MAX_WORDS_LARGE = 36
    const val JACCARD_SIMILARITY_THRESHOLD = 0.60
    const val LEVENSHTEIN_SIMILARITY_THRESHOLD = 0.72

    private val FORBIDDEN_ATTRIBUTIONS = listOf(
        "hippocrates", "william osler", "sir william osler", "osler", "charaka",
        "sushruta", "avicenna", "ibn sina", "galen", "atul gawande", "paul kalanithi",
        "henry marsh", "abraham verghese", "patch adams", "elizabeth blackwell",
        "virginia apgar", "alexander fleming", "louis pasteur", "robert koch",
        "marie curie", "sigmund freud", "carl jung", "nelson mandela", "confucius",
        "aristotle", "plato", "socrates", "einstein", "albert einstein"
    )

    private val GENERIC_CLICHES = listOf(
        "live laugh love",
        "sky is the limit",
        "follow your dreams no matter what",
        "winners never quit and quitters never win",
        "everything happens for a reason"
    )

    private val STOP_WORDS = setOf(
        "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
        "of", "with", "by", "from", "is", "are", "was", "were", "be", "been",
        "that", "this", "it", "as", "your", "you"
    )

    data class ValidationResult(
        val isValid: Boolean,
        val cleanedText: String = "",
        val normalizedHash: String = "",
        val rejectionReason: String? = null
    )

    /**
     * Cleans raw text from AI or offline generator by removing wrapping quotes,
     * markdown formatting, or leading labels.
     */
    fun sanitizeRawQuote(raw: String): String {
        var s = raw.trim()
        // Remove prefixes like "Quote:" or "MedInspire:"
        s = s.replace(Regex("^(?i)(quote|medinspire|motivational quote)\\s*:\\s*"), "")
        // Remove surrounding quotation marks or smart quotes
        s = s.trim('"', '\'', '“', '”', '‘', '’', '*', '_', ' ', '\n', '\r', '\t')
        // Collapse internal whitespace
        s = s.replace(Regex("\\s+"), " ").trim()
        return s
    }

    /**
     * Normalizes quote text for canonical comparison:
     * lowercase, alphanumeric and single spaces only.
     */
    fun normalizeText(text: String): String {
        return text
            .lowercase()
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /**
     * Computes a deterministic SHA-256 hex digest of the normalized quote text.
     */
    fun computeNormalizedHash(text: String): String {
        val normalized = normalizeText(text)
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(normalized.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * Validates quote structure, word count, and absence of false attributions.
     */
    fun validateStructure(
        rawText: String,
        allowExtendedLength: Boolean = false
    ): ValidationResult {
        val cleaned = sanitizeRawQuote(rawText)
        if (cleaned.isBlank()) {
            return ValidationResult(false, rejectionReason = "Quote text is empty")
        }

        val words = cleaned.split(Regex("\\s+")).filter { it.isNotBlank() }
        val maxWords = if (allowExtendedLength) MAX_WORDS_LARGE else MAX_WORDS_STANDARD
        if (words.size < MIN_WORDS) {
            return ValidationResult(
                false,
                cleanedText = cleaned,
                rejectionReason = "Quote too short (${words.size} words; minimum is $MIN_WORDS)"
            )
        }
        if (words.size > maxWords) {
            return ValidationResult(
                false,
                cleanedText = cleaned,
                rejectionReason = "Quote too long (${words.size} words; maximum is $maxWords)"
            )
        }

        val lower = cleaned.lowercase()

        // Reject trailing author attributions like " - Dr. ..." or " ~ William Osler"
        if (Regex("([—–~-]|\\bby\\b)\\s*(dr\\.?|sir\\s+|prof\\.?)?[a-z]+\\s+[a-z]+$").containsMatchIn(lower)) {
            return ValidationResult(
                false,
                cleanedText = cleaned,
                rejectionReason = "Contains author attribution suffix"
            )
        }

        for (forbidden in FORBIDDEN_ATTRIBUTIONS) {
            if (lower.contains(forbidden)) {
                return ValidationResult(
                    false,
                    cleanedText = cleaned,
                    rejectionReason = "Contains prohibited historical/author attribution: $forbidden"
                )
            }
        }

        for (cliche in GENERIC_CLICHES) {
            if (lower.contains(cliche)) {
                return ValidationResult(
                    false,
                    cleanedText = cleaned,
                    rejectionReason = "Contains generic non-medical cliche"
                )
            }
        }

        val hash = computeNormalizedHash(cleaned)
        return ValidationResult(
            isValid = true,
            cleanedText = cleaned,
            normalizedHash = hash
        )
    }

    /**
     * Computes word-level Jaccard similarity on meaningful tokens plus 2-word shingles.
     */
    fun tokenJaccardSimilarity(a: String, b: String): Double {
        val normA = normalizeText(a)
        val normB = normalizeText(b)
        if (normA == normB) return 1.0
        if (normA.isEmpty() || normB.isEmpty()) return 0.0

        val wordsA = normA.split(" ").filter { it.isNotBlank() }
        val wordsB = normB.split(" ").filter { it.isNotBlank() }

        val contentA = wordsA.filter { it !in STOP_WORDS }.toSet()
        val contentB = wordsB.filter { it !in STOP_WORDS }.toSet()

        val bigramsA = wordsA.zipWithNext { x, y -> "$x $y" }.toSet()
        val bigramsB = wordsB.zipWithNext { x, y -> "$x $y" }.toSet()

        val featuresA = contentA + bigramsA
        val featuresB = contentB + bigramsB
        if (featuresA.isEmpty() || featuresB.isEmpty()) return 0.0

        val intersection = featuresA.intersect(featuresB).size.toDouble()
        val union = featuresA.union(featuresB).size.toDouble()
        return intersection / union
    }

    /**
     * Computes normalized character-level Levenshtein similarity in [0.0, 1.0].
     */
    fun levenshteinSimilarity(a: String, b: String): Double {
        val s1 = normalizeText(a)
        val s2 = normalizeText(b)
        if (s1 == s2) return 1.0
        val maxLen = max(s1.length, s2.length)
        if (maxLen == 0) return 1.0

        val prev = IntArray(s2.length + 1) { it }
        val curr = IntArray(s2.length + 1)

        for (i in 1..s1.length) {
            curr[0] = i
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                curr[j] = min(
                    min(curr[j - 1] + 1, prev[j] + 1),
                    prev[j - 1] + cost
                )
            }
            System.arraycopy(curr, 0, prev, 0, s2.length + 1)
        }
        val distance = prev[s2.length]
        return 1.0 - (distance.toDouble() / maxLen.toDouble())
    }

    /**
     * Checks whether a candidate quote is an exact duplicate or too similar to any quote
     * in existingHashes or recentQuoteTexts.
     */
    fun isDuplicateOrTooSimilar(
        candidateText: String,
        existingHashes: Set<String>,
        recentQuoteTexts: Iterable<String>
    ): Boolean {
        val candidateNorm = normalizeText(candidateText)
        val candidateHash = computeNormalizedHash(candidateText)
        if (candidateHash in existingHashes) return true

        for (existing in recentQuoteTexts) {
            if (normalizeText(existing) == candidateNorm) return true
            if (tokenJaccardSimilarity(candidateText, existing) >= JACCARD_SIMILARITY_THRESHOLD) {
                return true
            }
            if (levenshteinSimilarity(candidateText, existing) >= LEVENSHTEIN_SIMILARITY_THRESHOLD) {
                return true
            }
        }
        return false
    }
}
