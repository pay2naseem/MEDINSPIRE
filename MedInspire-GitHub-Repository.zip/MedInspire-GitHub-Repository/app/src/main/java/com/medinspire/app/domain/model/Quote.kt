package com.medinspire.app.domain.model

enum class QuoteSourceMode(val label: String) {
    AI_ONLINE("Online AI"),
    OFFLINE_ENGINE("Offline Mode")
}

enum class WidgetThemeMode(val id: String, val label: String) {
    DARK_NAVY("dark", "Midnight Navy (Dark)"),
    LIGHT_IVORY("light", "Clinical Ivory (Light)"),
    SYSTEM_AUTO("auto", "Automatic (System)")
}

enum class QuoteTextSize(val id: String, val label: String, val scaleFactor: Float) {
    COMPACT("compact", "Compact", 0.90f),
    STANDARD("standard", "Standard", 1.00f),
    LARGE("large", "Large", 1.12f)
}

data class Quote(
    val id: Long = 0L,
    val text: String,
    val category: QuoteCategory,
    val sourceMode: QuoteSourceMode,
    val attribution: String = "MedInspire Original",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val normalizedHash: String
)
