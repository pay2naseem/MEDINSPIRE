package com.medinspire.app.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Restores the most recent valid motivational quote across all placed widgets
 * after device reboot or app upgrade, and re-schedules periodic WorkManager refresh.
 */
class WidgetRestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            WidgetRefreshWorker.enqueuePeriodicWork(context)
            MedInspireWidgetProvider.updateAllWidgets(context, isLoading = false)
        }
    }
}
