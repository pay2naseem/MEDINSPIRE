package com.medinspire.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.medinspire.app.domain.model.WidgetThemeMode

val MidnightNavy = Color(0xFF0A1128)
val DeepSlateNavy = Color(0xFF0F172A)
val CardNavy = Color(0xFF152238)
val MedTeal = Color(0xFF14B8A6)
val MedAqua = Color(0xFF38BDF8)
val TextIvory = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)

val ClinicalIvory = Color(0xFFF8FAFC)
val ClinicalSurface = Color(0xFFFFFFFF)
val DeepTeal = Color(0xFF0F766E)
val SlateInk = Color(0xFF0F172A)

private val DarkPalette = darkColorScheme(
    primary = MedTeal,
    secondary = MedAqua,
    background = MidnightNavy,
    surface = CardNavy,
    onPrimary = MidnightNavy,
    onSecondary = MidnightNavy,
    onBackground = TextIvory,
    onSurface = TextIvory
)

private val LightPalette = lightColorScheme(
    primary = DeepTeal,
    secondary = Color(0xFF0284C7),
    background = ClinicalIvory,
    surface = ClinicalSurface,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = SlateInk,
    onSurface = SlateInk
)

@Composable
fun MedInspireTheme(
    themeMode: WidgetThemeMode = WidgetThemeMode.DARK_NAVY,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        WidgetThemeMode.DARK_NAVY -> true
        WidgetThemeMode.LIGHT_IVORY -> false
        WidgetThemeMode.SYSTEM_AUTO -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (darkTheme) DarkPalette else LightPalette,
        content = content
    )
}
