package com.medinspire.app.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.medinspire.app.domain.model.Quote
import com.medinspire.app.domain.model.QuoteCategory
import com.medinspire.app.domain.model.QuoteSourceMode

@Entity(
    tableName = "quotes",
    indices = [
        Index(value = ["normalized_hash"], unique = true),
        Index(value = ["created_at_millis"]),
        Index(value = ["is_favorite"])
    ]
)
data class QuoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "quote_text")
    val text: String,

    @ColumnInfo(name = "category_id")
    val categoryId: String,

    @ColumnInfo(name = "source_mode")
    val sourceMode: String,

    @ColumnInfo(name = "attribution")
    val attribution: String = "MedInspire Original",

    @ColumnInfo(name = "created_at_millis")
    val createdAtMillis: Long,

    @ColumnInfo(name = "is_favorite")
    val isFavorite: Boolean = false,

    @ColumnInfo(name = "normalized_hash")
    val normalizedHash: String
) {
    fun toDomain(): Quote = Quote(
        id = id,
        text = text,
        category = QuoteCategory.fromId(categoryId),
        sourceMode = if (sourceMode == QuoteSourceMode.AI_ONLINE.name) {
            QuoteSourceMode.AI_ONLINE
        } else {
            QuoteSourceMode.OFFLINE_ENGINE
        },
        attribution = attribution,
        createdAtMillis = createdAtMillis,
        isFavorite = isFavorite,
        normalizedHash = normalizedHash
    )

    companion object {
        fun fromDomain(quote: Quote): QuoteEntity = QuoteEntity(
            id = quote.id,
            text = quote.text,
            categoryId = quote.category.id,
            sourceMode = quote.sourceMode.name,
            attribution = quote.attribution,
            createdAtMillis = quote.createdAtMillis,
            isFavorite = quote.isFavorite,
            normalizedHash = quote.normalizedHash
        )
    }
}
