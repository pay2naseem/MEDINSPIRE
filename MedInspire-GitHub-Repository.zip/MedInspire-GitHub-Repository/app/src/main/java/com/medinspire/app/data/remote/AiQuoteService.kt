package com.medinspire.app.data.remote

import com.medinspire.app.domain.model.QuoteCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentLinkedQueue
import javax.net.ssl.HttpsURLConnection
import kotlin.random.Random

/**
 * Secure HTTPS client for the MedInspire AI Quote Generation Backend.
 *
 * Security invariants:
 * - Never embeds or transmits private LLM provider keys from the Android client.
 * - Requires HTTPS (TLS) for remote calls (allows localhost/10.0.2.2 only for local emulator testing).
 * - Enforces client-side rate limiting (max 6 requests per 60 seconds) and timeouts.
 */
class AiQuoteService {

    companion object {
        private const val CONNECT_TIMEOUT_MS = 6500
        private const val READ_TIMEOUT_MS = 8500
        private const val MAX_REQUESTS_PER_MINUTE = 6

        private val EMOTIONAL_TONES = listOf(
            "calm and resolute",
            "grounded and reflective",
            "quietly fierce and disciplined",
            "compassionate and humanistic",
            "mentor-like and encouraging",
            "focused and analytical"
        )

        private val WRITING_STYLES = listOf(
            "concise clinical aphorism",
            "contrastive two-part medical reflection",
            "direct second-person encouragement for a medical student",
            "observational bedside wisdom",
            "quiet late-night study reminder"
        )
    }

    private val requestTimestamps = ConcurrentLinkedQueue<Long>()

    data class AiQuoteRequestPayload(
        val category: QuoteCategory,
        val specialty: String,
        val emotionalTone: String,
        val writingStyle: String,
        val targetWordRange: String,
        val avoidRecentHashes: List<String>,
        val attemptNumber: Int
    ) {
        fun toJson(): String {
            val obj = JSONObject()
            obj.put("categoryId", category.id)
            obj.put("categoryName", category.displayName)
            obj.put("specialty", specialty)
            obj.put("emotionalTone", emotionalTone)
            obj.put("writingStyle", writingStyle)
            obj.put("targetWordRange", targetWordRange)
            obj.put("attemptNumber", attemptNumber)
            obj.put(
                "systemInstruction",
                "Generate one original motivational quote (8 to 25 words) for an MBBS medical student or resident. " +
                    "Focus on ${category.displayName} ($specialty) with a $emotionalTone tone in a $writingStyle style. " +
                    "Do not include quotation marks, author names, or famous doctor attributions."
            )
            val hashesArr = JSONArray()
            avoidRecentHashes.take(25).forEach { hashesArr.put(it) }
            obj.put("avoidNormalizedHashes", hashesArr)
            return obj.toString()
        }
    }

    sealed class AiResult {
        data class Success(val quoteText: String, val category: QuoteCategory) : AiResult()
        data class Failure(val reason: String, val isRecoverableOffline: Boolean = true) : AiResult()
    }

    fun buildRandomizedPayload(
        categories: Set<QuoteCategory>,
        recentHashes: List<String>,
        allowExtendedLength: Boolean,
        attemptNumber: Int,
        random: Random = Random.Default
    ): AiQuoteRequestPayload {
        val pool = if (categories.isEmpty()) QuoteCategory.entries else categories.toList()
        val chosenCategory = pool.random(random)
        val chosenSpecialty = chosenCategory.specialties.random(random)
        val chosenTone = EMOTIONAL_TONES.random(random)
        val chosenStyle = WRITING_STYLES.random(random)
        val wordRange = if (allowExtendedLength) "10-28 words" else "8-22 words"

        return AiQuoteRequestPayload(
            category = chosenCategory,
            specialty = chosenSpecialty,
            emotionalTone = chosenTone,
            writingStyle = chosenStyle,
            targetWordRange = wordRange,
            avoidRecentHashes = recentHashes,
            attemptNumber = attemptNumber
        )
    }

    private fun checkAndRecordRateLimit(): Boolean {
        val now = System.currentTimeMillis()
        while (true) {
            val head = requestTimestamps.peek() ?: break
            if (now - head > 60_000L) {
                requestTimestamps.poll()
            } else {
                break
            }
        }
        if (requestTimestamps.size >= MAX_REQUESTS_PER_MINUTE) {
            return false
        }
        requestTimestamps.add(now)
        return true
    }

    suspend fun requestQuoteFromBackend(
        endpointUrl: String,
        clientToken: String,
        payload: AiQuoteRequestPayload
    ): AiResult = withContext(Dispatchers.IO) {
        val cleanUrl = endpointUrl.trim()
        if (cleanUrl.isBlank()) {
            return@withContext AiResult.Failure("No AI backend endpoint configured")
        }

        val parsedUrl = try {
            URL(cleanUrl)
        } catch (e: Exception) {
            return@withContext AiResult.Failure("Invalid endpoint URL format")
        }

        val isLocalDev = parsedUrl.host == "10.0.2.2" || parsedUrl.host == "localhost" || parsedUrl.host == "127.0.0.1"
        if (!parsedUrl.protocol.equals("https", ignoreCase = true) && !isLocalDev) {
            return@withContext AiResult.Failure("Security policy requires an HTTPS backend URL")
        }

        if (!checkAndRecordRateLimit()) {
            return@withContext AiResult.Failure("Client rate limit reached (max $MAX_REQUESTS_PER_MINUTE/min)")
        }

        var connection: HttpURLConnection? = null
        try {
            connection = (parsedUrl.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doInput = true
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-MedInspire-Client", "Android/1.0.0")
                if (clientToken.isNotBlank()) {
                    setRequestProperty("Authorization", "Bearer $clientToken")
                }
            }

            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(payload.toJson())
                writer.flush()
            }

            val status = connection.responseCode
            if (status !in 200..299) {
                return@withContext AiResult.Failure("Backend returned HTTP $status")
            }

            val responseBody = BufferedReader(
                InputStreamReader(connection.inputStream, Charsets.UTF_8)
            ).use { it.readText() }

            val json = JSONObject(responseBody)
            val quoteText = when {
                json.has("quote") -> json.optString("quote", "")
                json.has("text") -> json.optString("text", "")
                json.has("data") -> json.optJSONObject("data")?.optString("quote", "") ?: ""
                else -> ""
            }

            if (quoteText.isBlank()) {
                return@withContext AiResult.Failure("Backend JSON did not contain a valid 'quote' field")
            }

            AiResult.Success(quoteText = quoteText, category = payload.category)
        } catch (e: Exception) {
            AiResult.Failure("Network/API error: ${e.javaClass.simpleName}")
        } finally {
            connection?.disconnect()
        }
    }
}
