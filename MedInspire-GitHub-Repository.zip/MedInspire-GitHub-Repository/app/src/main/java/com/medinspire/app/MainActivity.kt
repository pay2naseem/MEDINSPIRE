package com.medinspire.app

import android.appwidget.AppWidgetManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.medinspire.app.data.preferences.UserSettings
import com.medinspire.app.domain.model.Quote
import com.medinspire.app.domain.model.QuoteCategory
import com.medinspire.app.domain.model.QuoteSourceMode
import com.medinspire.app.domain.model.QuoteTextSize
import com.medinspire.app.domain.model.WidgetThemeMode
import com.medinspire.app.ui.MedInspireViewModel
import com.medinspire.app.ui.theme.CardNavy
import com.medinspire.app.ui.theme.MedAqua
import com.medinspire.app.ui.theme.MedInspireTheme
import com.medinspire.app.ui.theme.MedTeal
import com.medinspire.app.ui.theme.MidnightNavy
import com.medinspire.app.widget.MedInspireWidgetProvider

class MainActivity : ComponentActivity() {

    private val viewModel: MedInspireViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settings by viewModel.settings.collectAsState()
            val currentQuote by viewModel.currentQuote.collectAsState()
            val favorites by viewModel.favorites.collectAsState()
            val history by viewModel.history.collectAsState()
            val isGenerating by viewModel.isGenerating.collectAsState()

            MedInspireTheme(themeMode = settings.themeMode) {
                MedInspireAppScreen(
                    currentQuote = currentQuote,
                    favorites = favorites,
                    history = history,
                    settings = settings,
                    isGenerating = isGenerating,
                    onNewQuote = { viewModel.requestNewQuote() },
                    onToggleFavorite = { viewModel.toggleFavorite(it) },
                    onToggleCategory = { viewModel.toggleCategory(it) },
                    onUpdateTheme = { viewModel.updateTheme(it) },
                    onUpdateTextSize = { viewModel.updateTextSize(it) },
                    onUpdateWidgetOptions = { attr, tap, hrs ->
                        viewModel.updateWidgetOptions(attr, tap, hrs)
                    },
                    onUpdateAiConfig = { url, token, offline ->
                        viewModel.updateAiConfig(url, token, offline)
                    },
                    onClearHistory = { viewModel.clearHistory() },
                    onPinWidget = { requestPinWidget(this) }
                )
            }
        }
    }

    private fun requestPinWidget(context: Context) {
        val appWidgetManager = AppWidgetManager.getInstance(context)
        val provider = ComponentName(context, MedInspireWidgetProvider::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && appWidgetManager.isRequestPinAppWidgetSupported) {
            appWidgetManager.requestPinAppWidget(provider, null, null)
        } else {
            Toast.makeText(
                context,
                "Long-press an empty space on your home screen, tap Widgets, and select MedInspire.",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

@Composable
fun MedInspireAppScreen(
    currentQuote: Quote?,
    favorites: List<Quote>,
    history: List<Quote>,
    settings: UserSettings,
    isGenerating: Boolean,
    onNewQuote: () -> Unit,
    onToggleFavorite: (Quote) -> Unit,
    onToggleCategory: (QuoteCategory) -> Unit,
    onUpdateTheme: (WidgetThemeMode) -> Unit,
    onUpdateTextSize: (QuoteTextSize) -> Unit,
    onUpdateWidgetOptions: (Boolean, Boolean, Int) -> Unit,
    onUpdateAiConfig: (String, String, Boolean) -> Unit,
    onClearHistory: () -> Unit,
    onPinWidget: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Home", "Categories", "Favorites", "History", "Settings")

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = CardNavy) {
                tabs.forEachIndexed { index, title ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        label = { Text(title, fontSize = 11.sp) },
                        icon = { Text(if (selectedTab == index) "●" else "○", color = MedTeal) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> HomeTab(
                    quote = currentQuote,
                    settings = settings,
                    isGenerating = isGenerating,
                    onNewQuote = onNewQuote,
                    onToggleFavorite = onToggleFavorite,
                    onPinWidget = onPinWidget
                )
                1 -> CategoriesTab(
                    selectedCategories = settings.selectedCategories,
                    onToggleCategory = onToggleCategory
                )
                2 -> FavoritesTab(
                    favorites = favorites,
                    onToggleFavorite = onToggleFavorite
                )
                3 -> HistoryTab(
                    history = history,
                    onToggleFavorite = onToggleFavorite,
                    onClearHistory = onClearHistory
                )
                4 -> SettingsTab(
                    settings = settings,
                    onUpdateTheme = onUpdateTheme,
                    onUpdateTextSize = onUpdateTextSize,
                    onUpdateWidgetOptions = onUpdateWidgetOptions,
                    onUpdateAiConfig = onUpdateAiConfig
                )
            }
        }
    }
}

@Composable
private fun HomeTab(
    quote: Quote?,
    settings: UserSettings,
    isGenerating: Boolean,
    onNewQuote: () -> Unit,
    onToggleFavorite: (Quote) -> Unit,
    onPinWidget: () -> Unit
) {
    val context = LocalContext.current
    var previewSizeTier by remember { mutableStateOf("4×2") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "MEDINSPIRE • MEDICAL MOTIVATION",
                color = MedTeal,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Daily Resilience for MBBS & Clinical Practice",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        // Source Mode Status Indicator
        item {
            val isAiReady = !settings.forceOfflineMode && settings.aiEndpointUrl.isNotBlank()
            val modeText = if (quote?.sourceMode == QuoteSourceMode.AI_ONLINE) {
                "Source: Live Online AI Generation"
            } else if (isAiReady) {
                "Source: Offline Fallback (AI Endpoint Configured)"
            } else {
                "Source: Offline Mode (Compositional & Curated Engine)"
            }
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MedTeal.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, MedTeal.copy(alpha = 0.45f))
            ) {
                Text(
                    text = modeText,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    color = MedAqua,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Main Hero Quote Preview Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.dp, MedTeal.copy(alpha = 0.5f)),
                colors = CardDefaults.cardColors(containerColor = MidnightNavy)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF0A1128), Color(0xFF0F1E38), Color(0xFF13294B))
                            )
                        )
                        .padding(22.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = quote?.category?.displayName ?: "MBBS Motivation",
                            color = MedAqua,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (isGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MedTeal
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "“${quote?.text ?: "Clinical competence is built quietly in the hours when nobody is applauding your discipline."}”",
                        color = Color(0xFFF8FAFC),
                        fontSize = (18f * settings.quoteTextSize.scaleFactor).sp,
                        fontFamily = FontFamily.Serif,
                        lineHeight = 26.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "─── ﮩ٨ـﮩﮩ٨ـ♡ﮩ٨ـﮩﮩ٨ـ ───  ${quote?.attribution ?: "MedInspire Original"}",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Primary Actions: New Quote, Copy, Favorite, Share
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onNewQuote,
                    modifier = Modifier.weight(1.3f),
                    colors = ButtonDefaults.buttonColors(containerColor = MedTeal)
                ) {
                    Text(
                        text = if (isGenerating) "Generating…" else "↻ New Quote",
                        color = MidnightNavy,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = {
                        quote?.let {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("MedInspire Quote", it.text))
                            Toast.makeText(context, "Quote copied to clipboard", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(0.9f)
                ) {
                    Text("Copy")
                }

                OutlinedButton(
                    onClick = { quote?.let { onToggleFavorite(it) } },
                    modifier = Modifier.weight(0.9f)
                ) {
                    Text(if (quote?.isFavorite == true) "★ Saved" else "☆ Save")
                }
            }
        }

        // Add Widget to Home Screen Button
        item {
            Button(
                onClick = onPinWidget,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = CardNavy),
                border = BorderStroke(1.dp, MedAqua.copy(alpha = 0.6f))
            ) {
                Text(
                    text = "＋ Add Home-Screen Widget (2×2, 4×2, 4×3)",
                    color = MedAqua,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Interactive Home-Screen Widget Size Preview
        item {
            Text(
                text = "Home-Screen Widget Size Preview",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("2×2", "4×2", "4×3").forEach { tier ->
                    FilterChip(
                        selected = previewSizeTier == tier,
                        onClick = { previewSizeTier = tier },
                        label = { Text("$tier Widget") }
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            val previewWidthFraction = if (previewSizeTier == "2×2") 0.58f else 1.0f
            val previewMaxLines = when (previewSizeTier) {
                "2×2" -> 4
                "4×2" -> 4
                else -> 7
            }
            Card(
                modifier = Modifier.fillMaxWidth(previewWidthFraction),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, MedTeal.copy(alpha = 0.45f)),
                colors = CardDefaults.cardColors(containerColor = MidnightNavy)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "MEDINSPIRE ($previewSizeTier)",
                            color = MedTeal,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(text = "↻", color = MedAqua, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = quote?.text ?: "",
                        color = Color.White,
                        fontSize = if (previewSizeTier == "2×2") 12.sp else 14.sp,
                        fontFamily = FontFamily.Serif,
                        maxLines = previewMaxLines
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoriesTab(
    selectedCategories: Set<QuoteCategory>,
    onToggleCategory: (QuoteCategory) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "Preferred MBBS & Medical Categories",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Select the topics that match your current posting or exam preparation.",
                fontSize = 13.sp,
                color = Color(0xFF94A3B8)
            )
        }
        items(QuoteCategory.entries) { category ->
            val isSelected = selectedCategories.contains(category)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleCategory(category) },
                border = BorderStroke(
                    1.dp,
                    if (isSelected) MedTeal else Color.Gray.copy(alpha = 0.3f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggleCategory(category) }
                    )
                    Column(modifier = Modifier.padding(start = 8.dp)) {
                        Text(text = category.displayName, fontWeight = FontWeight.Bold)
                        Text(
                            text = category.description,
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FavoritesTab(
    favorites: List<Quote>,
    onToggleFavorite: (Quote) -> Unit
) {
    val context = LocalContext.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Saved Favorite Quotes (${favorites.size})",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }
        if (favorites.isEmpty()) {
            item {
                Text(
                    text = "Tap ☆ Save on any motivational quote to bookmark it here for pre-viva or night-duty review.",
                    color = Color(0xFF94A3B8)
                )
            }
        } else {
            items(favorites, key = { it.id }) { item ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = item.category.displayName,
                            color = MedAqua,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "“${item.text}”",
                            fontFamily = FontFamily.Serif,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            TextButton(onClick = {
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, "“${item.text}” — MedInspire")
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Share Quote"))
                            }) {
                                Text("Share")
                            }
                            TextButton(onClick = { onToggleFavorite(item) }) {
                                Text("Remove Favorite")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryTab(
    history: List<Quote>,
    onToggleFavorite: (Quote) -> Unit,
    onClearHistory: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Quote History (${history.size})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                OutlinedButton(onClick = onClearHistory) {
                    Text("Clear History")
                }
            }
            Text(
                text = "Normalized SHA-256 hashes & similarity checks prevent repeats.",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )
        }
        items(history, key = { it.id }) { item ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${item.category.shortBadge} • ${item.sourceMode.label}",
                            color = MedTeal,
                            fontSize = 11.sp
                        )
                        Text(
                            text = if (item.isFavorite) "★" else "☆",
                            modifier = Modifier.clickable { onToggleFavorite(item) },
                            color = MedAqua
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = item.text, fontFamily = FontFamily.Serif, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingsTab(
    settings: UserSettings,
    onUpdateTheme: (WidgetThemeMode) -> Unit,
    onUpdateTextSize: (QuoteTextSize) -> Unit,
    onUpdateWidgetOptions: (Boolean, Boolean, Int) -> Unit,
    onUpdateAiConfig: (String, String, Boolean) -> Unit
) {
    var endpointInput by remember(settings.aiEndpointUrl) { mutableStateOf(settings.aiEndpointUrl) }
    var tokenInput by remember(settings.aiClientToken) { mutableStateOf(settings.aiClientToken) }
    var forceOffline by remember(settings.forceOfflineMode) { mutableStateOf(settings.forceOfflineMode) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Appearance & Widget Settings",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Text("Theme (App & Home-Screen Widget)", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WidgetThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = settings.themeMode == mode,
                        onClick = { onUpdateTheme(mode) },
                        label = { Text(mode.label) }
                    )
                }
            }
        }

        item {
            Text("Quote Text Size", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuoteTextSize.entries.forEach { size ->
                    FilterChip(
                        selected = settings.quoteTextSize == size,
                        onClick = { onUpdateTextSize(size) },
                        label = { Text(size.label) }
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Show 'MedInspire Original' attribution on widget")
                Switch(
                    checked = settings.showAttributionOnWidget,
                    onCheckedChange = {
                        onUpdateWidgetOptions(it, settings.tapQuoteToRefresh, settings.periodicRefreshHours)
                    }
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Tap quote text on widget to refresh immediately")
                Switch(
                    checked = settings.tapQuoteToRefresh,
                    onCheckedChange = {
                        onUpdateWidgetOptions(settings.showAttributionOnWidget, it, settings.periodicRefreshHours)
                    }
                )
            }
        }

        item {
            Text(
                text = "Secure AI Backend Configuration",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "No private API keys are stored in the APK. Connect an HTTPS backend proxy for live AI generation, or leave blank to use the built-in Offline Compositional & Curated Engine.",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = endpointInput,
                onValueChange = { endpointInput = it },
                label = { Text("HTTPS Backend URL (e.g. https://api.example.com/v1/quotes/generate)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = tokenInput,
                onValueChange = { tokenInput = it },
                label = { Text("Optional Client Bearer Token") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Force Offline Generation Mode")
                Switch(
                    checked = forceOffline,
                    onCheckedChange = { forceOffline = it }
                )
            }
            Button(
                onClick = { onUpdateAiConfig(endpointInput, tokenInput, forceOffline) },
                colors = ButtonDefaults.buttonColors(containerColor = MedTeal)
            ) {
                Text("Save AI Configuration", color = MidnightNavy, fontWeight = FontWeight.Bold)
            }
        }

        item {
            Text(
                text = "Privacy & Quote Uniqueness Guarantee",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "• All quotes, favorites, and preferences are stored locally on your device in SQLite/Room.
" +
                    "• Duplicate prevention uses case-insensitive SHA-256 normalized hashing plus Jaccard token & Levenshtein edit-distance similarity checks against your local history.
" +
                    "• While no generative system can mathematically guarantee infinite uniqueness across all time, MedInspire guarantees zero exact repeats within your retained local history.",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )
        }
    }
}
