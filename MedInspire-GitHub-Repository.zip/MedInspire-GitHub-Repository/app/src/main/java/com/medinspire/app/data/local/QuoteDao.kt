package com.medinspire.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface QuoteDao {

    @Query("SELECT * FROM quotes ORDER BY created_at_millis DESC LIMIT 1")
    suspend fun getLatestQuote(): QuoteEntity?

    @Query("SELECT * FROM quotes ORDER BY created_at_millis DESC LIMIT 1")
    fun observeLatestQuote(): Flow<QuoteEntity?>

    @Query("SELECT * FROM quotes ORDER BY created_at_millis DESC LIMIT :limit")
    fun observeHistory(limit: Int = 200): Flow<List<QuoteEntity>>

    @Query("SELECT * FROM quotes WHERE is_favorite = 1 ORDER BY created_at_millis DESC")
    fun observeFavorites(): Flow<List<QuoteEntity>>

    @Query("SELECT normalized_hash FROM quotes")
    suspend fun getAllNormalizedHashes(): List<String>

    @Query("SELECT quote_text FROM quotes ORDER BY created_at_millis DESC LIMIT :limit")
    suspend fun getRecentQuoteTexts(limit: Int = 150): List<String>

    @Query("SELECT COUNT(*) FROM quotes WHERE normalized_hash = :hash")
    suspend fun countByNormalizedHash(hash: String): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertQuote(quote: QuoteEntity): Long

    @Query("UPDATE quotes SET is_favorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean)

    @Query("DELETE FROM quotes WHERE is_favorite = 0")
    suspend fun clearNonFavoriteHistory()

    @Query(
        "DELETE FROM quotes WHERE is_favorite = 0 AND id NOT IN " +
            "(SELECT id FROM quotes ORDER BY created_at_millis DESC LIMIT :maxRetained)"
    )
    suspend fun pruneOldHistory(maxRetained: Int = 400)
}
