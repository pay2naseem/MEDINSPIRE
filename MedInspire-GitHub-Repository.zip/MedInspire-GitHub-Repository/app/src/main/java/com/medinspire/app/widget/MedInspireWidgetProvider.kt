package com.medinspire.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import com.medinspire.app.MainActivity
import com.medinspire.app.R
import com.medinspire.app.data.preferences.UserPreferencesRepository
import com.medinspire.app.data.preferences.UserSettings
import com.medinspire.app.data.repository.QuoteRepository
import com.medinspire.app.domain.model.Quote
import com.medinspire.app.domain.model.WidgetThemeMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Native Android Home-Screen Widget Provider for MedInspire.
 *
 * Supports:
 * - Adaptive 2x2, 4x2, and 4x3 layouts via onAppWidgetOptionsChanged and dedicated providers.
 * - Explicit refresh button and tap-on-quote refresh directly on the Android home screen.
 * - Loading indicator while keeping the previous valid quote visible during generation.
 * - Midnight Navy (Dark) and Clinical Ivory (Light) themes.
 * - Dynamic font sizing based on quote length, widget dimensions, and user settings.
 */
open class MedInspireWidgetProvider : AppWidgetProvider() {

    protected open val defaultSizeTier: WidgetSizeTier = WidgetSizeTier.MEDIUM_4X2

    enum class WidgetSizeTier {
        COMPACT_2X2,
        MEDIUM_4X2,
        LARGE_4X3
    }

    companion object {
        const val ACTION_REFRESH_WIDGET = "com.medinspire.app.ACTION_REFRESH_WIDGET"
        const val ACTION_TAP_QUOTE = "com.medinspire.app.ACTION_TAP_QUOTE"
        const val EXTRA_WIDGET_ID = "extra_widget_id"

        private val widgetScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        fun updateAllWidgets(context: Context, isLoading: Boolean = false) {
            widgetScope.launch {
                val repo = QuoteRepository(context)
                val prefsRepo = UserPreferencesRepository(context)
                val quote = repo.getOrEnsureCurrentQuote()
                val settings = prefsRepo.settingsFlow.first()
                val manager = AppWidgetManager.getInstance(context)

                val providers = listOf(
                    ComponentName(context, MedInspireWidgetProvider::class.java) to WidgetSizeTier.MEDIUM_4X2,
                    ComponentName(context, MedInspireCompactWidgetProvider::class.java) to WidgetSizeTier.COMPACT_2X2,
                    ComponentName(context, MedInspireLargeWidgetProvider::class.java) to WidgetSizeTier.LARGE_4X3
                )

                for ((component, fallbackTier) in providers) {
                    val ids = manager.getAppWidgetIds(component)
                    for (widgetId in ids) {
                        val options = manager.getAppWidgetOptions(widgetId)
                        val tier = resolveSizeTier(options, fallbackTier)
                        val views = buildRemoteViews(
                            context = context,
                            widgetId = widgetId,
                            tier = tier,
                            quote = quote,
                            settings = settings,
                            isLoading = isLoading
                        )
                        manager.updateAppWidget(widgetId, views)
                    }
                }
            }
        }

        fun resolveSizeTier(options: Bundle?, fallback: WidgetSizeTier): WidgetSizeTier {
            if (options == null) return fallback
            val minWidth = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            val minHeight = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
            if (minWidth == 0 && minHeight == 0) return fallback

            return when {
                minWidth < 190 -> WidgetSizeTier.COMPACT_2X2
                minHeight >= 165 -> WidgetSizeTier.LARGE_4X3
                else -> WidgetSizeTier.MEDIUM_4X2
            }
        }

        fun buildRemoteViews(
            context: Context,
            widgetId: Int,
            tier: WidgetSizeTier,
            quote: Quote,
            settings: UserSettings,
            isLoading: Boolean
        ): RemoteViews {
            val layoutId = when (tier) {
                WidgetSizeTier.COMPACT_2X2 -> R.layout.widget_med_inspire_2x2
                WidgetSizeTier.MEDIUM_4X2 -> R.layout.widget_med_inspire_4x2
                WidgetSizeTier.LARGE_4X3 -> R.layout.widget_med_inspire_4x3
            }

            val views = RemoteViews(context.packageName, layoutId)

            // Resolve Light vs Dark theme
            val isSystemNight = (context.resources.configuration.uiMode and
                Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            val useDarkTheme = when (settings.themeMode) {
                WidgetThemeMode.DARK_NAVY -> true
                WidgetThemeMode.LIGHT_IVORY -> false
                WidgetThemeMode.SYSTEM_AUTO -> isSystemNight
            }

            val bgRes = if (useDarkTheme) {
                R.drawable.bg_widget_midnight_navy
            } else {
                R.drawable.bg_widget_light_ivory
            }
            views.setInt(R.id.widget_root, "setBackgroundResource", bgRes)

            val quoteColor = if (useDarkTheme) 0xFFF8FAFC.toInt() else 0xFF0F172A.toInt()
            val brandColor = if (useDarkTheme) 0xFF14B8A6.toInt() else 0xFF0F766E.toInt()
            val categoryColor = if (useDarkTheme) 0xFF38BDF8.toInt() else 0xFF0284C7.toInt()
            val attrColor = if (useDarkTheme) 0xFF94A3B8.toInt() else 0xFF475569.toInt()

            views.setTextColor(R.id.widget_quote_text, quoteColor)
            views.setTextColor(R.id.widget_brand_label, brandColor)
            views.setTextColor(R.id.widget_category_label, categoryColor)
            views.setTextColor(R.id.widget_attribution_text, attrColor)

            // Dynamic font size calculation to avoid clipping
            val baseSp = when (tier) {
                WidgetSizeTier.COMPACT_2X2 -> when {
                    quote.text.length > 115 -> 11.5f
                    quote.text.length > 85 -> 12.5f
                    else -> 13.5f
                }
                WidgetSizeTier.MEDIUM_4X2 -> when {
                    quote.text.length > 135 -> 13.0f
                    quote.text.length > 95 -> 14.5f
                    else -> 15.5f
                }
                WidgetSizeTier.LARGE_4X3 -> when {
                    quote.text.length > 160 -> 15.0f
                    quote.text.length > 115 -> 16.5f
                    else -> 18.0f
                }
            }
            val scaledSp = baseSp * settings.quoteTextSize.scaleFactor
            views.setTextViewTextSize(R.id.widget_quote_text, TypedValue.COMPLEX_UNIT_SP, scaledSp)

            // Populate quote, category, and attribution
            views.setTextViewText(R.id.widget_quote_text, "“${quote.text}”")
            val modeTag = if (quote.sourceMode.name == "AI_ONLINE") "AI" else "Offline"
            views.setTextViewText(
                R.id.widget_category_label,
                if (tier == WidgetSizeTier.COMPACT_2X2) {
                    quote.category.shortBadge
                } else {
                    "• ${quote.category.shortBadge} ($modeTag)"
                }
            )

            val showAttr = settings.showAttributionOnWidget && tier != WidgetSizeTier.COMPACT_2X2
            views.setViewVisibility(
                R.id.widget_attribution_text,
                if (showAttr) View.VISIBLE else View.GONE
            )
            views.setTextViewText(R.id.widget_attribution_text, quote.attribution)

            // Loading state keeps existing quote visible while showing progress indicator
            views.setViewVisibility(
                R.id.widget_loading_progress,
                if (isLoading) View.VISIBLE else View.GONE
            )
            views.setViewVisibility(
                R.id.widget_refresh_btn,
                if (isLoading) View.INVISIBLE else View.VISIBLE
            )

            // PendingIntent 1: Refresh button explicit tap
            val refreshIntent = Intent(context, MedInspireWidgetProvider::class.java).apply {
                action = ACTION_REFRESH_WIDGET
                putExtra(EXTRA_WIDGET_ID, widgetId)
            }
            val refreshPendingIntent = PendingIntent.getBroadcast(
                context,
                widgetId + 1000,
                refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_refresh_btn, refreshPendingIntent)

            // PendingIntent 2: Tapping the quote area (refresh quote or open app per user setting)
            if (settings.tapQuoteToRefresh) {
                val tapQuoteIntent = Intent(context, MedInspireWidgetProvider::class.java).apply {
                    action = ACTION_TAP_QUOTE
                    putExtra(EXTRA_WIDGET_ID, widgetId)
                }
                val tapQuotePendingIntent = PendingIntent.getBroadcast(
                    context,
                    widgetId + 2000,
                    tapQuoteIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_quote_text, tapQuotePendingIntent)
            } else {
                val openAppIntent = Intent(context, MainActivity::class.java)
                val openAppPendingIntent = PendingIntent.getActivity(
                    context,
                    widgetId + 3000,
                    openAppIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_quote_text, openAppPendingIntent)
            }

            // PendingIntent 3: Tapping the header/brand label always opens MainActivity
            val openAppHeaderIntent = Intent(context, MainActivity::class.java)
            val openAppHeaderPending = PendingIntent.getActivity(
                context,
                widgetId + 4000,
                openAppHeaderIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_brand_label, openAppHeaderPending)
            views.setOnClickPendingIntent(R.id.widget_ecg_icon, openAppHeaderPending)

            return views
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        WidgetRefreshWorker.enqueuePeriodicWork(context)
        updateAllWidgets(context, isLoading = false)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        val pendingResult = goAsync()
        widgetScope.launch {
            try {
                val repo = QuoteRepository(context)
                val prefsRepo = UserPreferencesRepository(context)
                val quote = repo.getOrEnsureCurrentQuote()
                val settings = prefsRepo.settingsFlow.first()
                val tier = resolveSizeTier(newOptions, defaultSizeTier)
                val views = buildRemoteViews(
                    context = context,
                    widgetId = appWidgetId,
                    tier = tier,
                    quote = quote,
                    settings = settings,
                    isLoading = false
                )
                appWidgetManager.updateAppWidget(appWidgetId, views)
            } finally {
                pendingResult.finish()
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (action == ACTION_REFRESH_WIDGET || action == ACTION_TAP_QUOTE) {
            val pendingResult = goAsync()
            widgetScope.launch {
                try {
                    // Show loading indicator while keeping current quote visible
                    updateAllWidgets(context, isLoading = true)
                    val repo = QuoteRepository(context)
                    repo.generateAndSaveNextQuote(
                        allowExtendedLength = (defaultSizeTier == WidgetSizeTier.LARGE_4X3)
                    )
                    updateAllWidgets(context, isLoading = false)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}

class MedInspireCompactWidgetProvider : MedInspireWidgetProvider() {
    override val defaultSizeTier: WidgetSizeTier = WidgetSizeTier.COMPACT_2X2
}

class MedInspireLargeWidgetProvider : MedInspireWidgetProvider() {
    override val defaultSizeTier: WidgetSizeTier = WidgetSizeTier.LARGE_4X3
}
