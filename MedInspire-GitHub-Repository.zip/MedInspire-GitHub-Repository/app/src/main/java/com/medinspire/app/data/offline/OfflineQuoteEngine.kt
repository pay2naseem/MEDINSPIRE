package com.medinspire.app.data.offline

import com.medinspire.app.domain.model.QuoteCategory
import com.medinspire.app.domain.validation.QuoteValidator
import kotlin.random.Random

/**
 * Dual-mode Offline Medical Quote Engine:
 * 1. Curated MedInspire Originals across all 10 MBBS / medical categories (100+ unique quotes).
 * 2. Compositional Medical Quote Generator combining category-specific clinical anchors,
 *    study realities, and ethical outcomes with duplicate & similarity avoidance.
 */
object OfflineQuoteEngine {

    private val curatedByCategory: Map<QuoteCategory, List<String>> = mapOf(
        QuoteCategory.MBBS_MOTIVATION to listOf(
            "Clinical competence is built quietly in the hours when nobody is applauding your discipline.",
            "Every chapter you decode tonight strengthens the calm you will bring to a chaotic emergency room.",
            "An MBBS degree is not won in sudden bursts of brilliance, but in relentless daily showing up.",
            "You are not merely memorizing textbooks; you are rehearsing decisions that will protect someone's family.",
            "The weight of the white coat feels lighter when your preparation is heavier than your doubt.",
            "Long lectures fade, but the clinical clarity you forge through patient curiosity stays for a career.",
            "Medicine rewards the student who treats every small concept as a future bedside lifeline.",
            "Behind every confident physician stands a medical student who refused to quit on an ordinary Tuesday.",
            "Your fatigue is temporary, but the diagnostic instincts you build tonight will serve thousands.",
            "Study not just to clear the professional exam, but to earn the quiet trust of a frightened patient."
        ),
        QuoteCategory.ANATOMY_PHYSIOLOGY to listOf(
            "Anatomy maps the architecture of survival; physiology reveals the tireless symphony keeping it alive.",
            "Every nerve course you trace in the dissection hall prevents hesitation in a future surgical field.",
            "Homeostasis teaches resilience: the human body adapts under pressure, and so does a trained medical mind.",
            "Master normal physiology deeply so that the subtlest pathological whisper never escapes your ear.",
            "From action potentials to cardiac output, understanding the mechanism turns rote memory into clinical sight.",
            "The brachial plexus and cranial nuclei reward patience; trace the pathway until your hands can see it.",
            "Starling's law and renal clearance are not abstract curves; they are the language of a critically ill bedside.",
            "Respect the precision of human anatomy; a millimeter of knowledge separates complication from recovery.",
            "When you understand how a single nephron guards balance, you learn how small efforts sustain the whole.",
            "Dissection teaches humility before human design and discipline before clinical intervention."
        ),
        QuoteCategory.PATHOLOGY_PHARMACOLOGY to listOf(
            "Pathology shows you how disease writes its signature; pharmacology gives you the ink to rewrite the outcome.",
            "Never memorize a drug dose without honoring the receptor, the clearance, and the patient carrying both.",
            "Beneath every slide of cellular injury lies a story of stress, adaptation, and the margin of recovery.",
            "A sharp clinician sees inflammation not as a list of mediators, but as a battlefield asking for precision.",
            "Pharmacokinetics is clinical stewardship: the right molecule, at the right receptor, with minimal harm.",
            "Robbins teaches why tissues fail; Goodman and Gilman teach how thoughtful intervention restores balance.",
            "Knowing the adverse effect before writing the prescription is the quiet mark of a careful doctor.",
            "Every mechanism of action you master replaces guesswork with deliberate therapeutic courage.",
            "Pathology bridges basic science and human suffering; read every biopsy finding with clinical empathy.",
            "Rational prescribing begins years earlier, at the desk where you refused to skip the mechanism."
        ),
        QuoteCategory.CLINICAL_ROTATIONS to listOf(
            "Textbooks describe diseases in clean paragraphs; ward rounds teach you how real patients speak.",
            "A thorough history taken with patience often reveals what an expensive scan misses.",
            "Stand close during morning rounds; clinical judgment is absorbed through attentive eyes and honest questions.",
            "Inspect, palpate, percuss, and auscultate with intention—your hands and ears are your first diagnostic lab.",
            "Every patient you examine in the general ward is generously lending their illness to your education.",
            "Clinical postings reward the student who listens to the symptom before rushing to the syndrome.",
            "The best bedside sign is the one you noticed because you actually looked at the patient's face.",
            "Ward work feels repetitive until the night an unfamiliar murmur or subtle icterus saves a life.",
            "Treat every clerkship case presentation as a rehearsal for the day the final decision is yours.",
            "A great clinician is forged at the foot of the hospital bed, one careful examination at a time."
        ),
        QuoteCategory.VIVA_EXAMS to listOf(
            "An examiner's toughest question only tests your composure; your daily preparation owns the answer.",
            "Walk into the practical viva like a bedside consultation: structured, honest, and calm under scrutiny.",
            "University exams measure recall for a week, but the clarity you build while revising lasts a lifetime.",
            "When a long case feels overwhelming, return to first principles: history, vital signs, and anatomical logic.",
            "A steady voice in the viva hall comes from having questioned yourself harder at your study desk.",
            "Do not fear the examiner's silence; organize your differentials from common and life-threatening downward.",
            "Every mock practical you endure strips away panic and leaves behind crisp clinical reasoning.",
            "Theory papers reward structure; practical vivas reward the student who has genuinely examined patients.",
            "Even if one station shakes your confidence, reset your breathing before the next clinical problem.",
            "Exams are checkpoints on the road to safe practice, not verdicts on your worth as a healer."
        ),
        QuoteCategory.NEET_PG_INI_CET to listOf(
            "Postgraduate preparation is a marathon of clinical reasoning where consistency outruns raw intensity.",
            "Every incorrect grand-test question is a free lesson preventing a mistake on exam day and in the ward.",
            "NEET-PG and INI-CET do not demand perfection; they reward calm pattern recognition built over months.",
            "Review your wrong answers with curiosity rather than frustration—that is where rank and mastery grow.",
            "One focused revision cycle beats ten distracted plans; protect your study hours with quiet resolve.",
            "Clinical vignettes test whether you can connect basic pathology to the next best step at the bedside.",
            "Do not compare your revision chapter with someone else's mock percentile; run your own disciplined pace.",
            "High-yield mastery is simply foundational medicine practiced until hesitation disappears.",
            "When grand-test scores plateau, refine your weak subjects quietly; breakthroughs follow steady repair.",
            "Each MCQ solved with deep conceptual clarity strengthens both your entrance rank and your future residency."
        ),
        QuoteCategory.DISCIPLINE_CONSISTENCY to listOf(
            "Thirty focused minutes with your notes when you are exhausted builds more grit than an easy five-hour day.",
            "Motivation starts the semester, but quiet daily routine carries you through professional finals.",
            "Clinical excellence is the compound interest of ordinary study evenings protected from distraction.",
            "You do not need an extraordinary mood to study medicine today; you only need to open the first page.",
            "Small daily revisions prevent the mountain of syllabus from turning into an avalanche before exams.",
            "Guard your focus like a sterile field: keep out noise, comparison, and unnecessary doubt.",
            "Consistency turns terrifying medical volumes into familiar clinical tools one topic at a time.",
            "Show up to your desk on time today; your future surgical or medical team will rely on that same habit.",
            "Discipline in medical school is choosing long-term patient safety over short-term comfort.",
            "Master one concept thoroughly before sleeping; three hundred such nights transform a student into a clinician."
        ),
        QuoteCategory.FAILURE_COMEBACKS to listOf(
            "A disappointing score or rough viva is a diagnostic report on your strategy, never a prognosis on your future.",
            "Every seasoned consultant once misread a sign, stumbled in a viva, and chose to study harder the next morning.",
            "Setbacks in medical training do not disqualify you; they teach the humility that safe medicine requires.",
            "When burnout whispers that you are behind, answer with one calm page, one topic, and one honest rest.",
            "You are allowed to feel tired after a brutal posting; rest briefly, adjust your method, and step back in.",
            "A missed question today is a clinical blind spot uncovered in time to be healed.",
            "Resilience in MBBS is walking back into the library after a paper that humbled you.",
            "No straight line ever produced a compassionate doctor; detours build depth and diagnostic patience.",
            "Forgive yesterday's unproductive hours and reclaim the next forty-five minutes with complete focus.",
            "Tough semesters forge steady hands; let difficulty sharpen your method rather than harden your heart."
        ),
        QuoteCategory.BECOMING_A_DOCTOR to listOf(
            "One day soon, the person looking around the room for the doctor will be looking directly at you.",
            "The transition from student to doctor happens the moment you care more about the patient than the grade.",
            "Wear your stethoscope with humility; it connects your years of study to another human being's heartbeat.",
            "Clinical maturity grows when you pair scientific rigor with the courage to accept responsibility.",
            "You begin MBBS learning how organs work; you graduate learning how to steady people on their worst days.",
            "Every night duty and ward note is shaping the calm clinician someone will pray for at three in the morning.",
            "Competence earns your license; integrity and vigilance earn your patients' lifelong trust.",
            "Step by step, the unfamiliar medical vocabulary you struggle with today becomes your native healing tongue.",
            "A doctor is built in layers: curiosity first, discipline second, clinical judgment third, compassion always.",
            "Keep refining your craft; the standard you hold in medical school becomes the standard of your hospital."
        ),
        QuoteCategory.PATIENT_CARE_COMPASSION to listOf(
            "To you, it may be the twentieth case of the morning; to the patient, it is a turning point in life.",
            "Science tells you what disease the patient has; empathy tells you who the patient is.",
            "A calm explanation at the bedside often relieves pain before the analgesic even reaches the bloodstream.",
            "Never let laboratory numbers eclipse the frightened human eyes waiting for you to interpret them.",
            "Compassion without clinical competence is helpless; competence without compassion is cold—cultivate both.",
            "Listening without interruption for sixty seconds is one of the most powerful diagnostic tools in medicine.",
            "Every chart represents a person who trusted strangers in white coats with their vulnerability.",
            "Cure when pathology permits, relieve suffering always, and never leave a patient feeling unheard.",
            "The finest medical technology still relies on a physician who notices a trembling hand.",
            "Lifelong learning is the highest form of respect a doctor can offer to tomorrow's patients."
        )
    )

    // Compositional generator fragments by category for synthesizing thousands of unique quotes
    private data class CompositionalFragments(
        val openings: List<String>,
        val bridges: List<String>,
        val resolutions: List<String>
    )

    private val compositionalByCategory: Map<QuoteCategory, CompositionalFragments> = mapOf(
        QuoteCategory.MBBS_MOTIVATION to CompositionalFragments(
            openings = listOf(
                "Every focused hour at your study table",
                "Each difficult concept you untangle in MBBS",
                "The quiet discipline you practice between lectures",
                "Every clinical correlation you question deeply",
                "Each page of medicine you master with patience"
            ),
            bridges = listOf(
                "builds the diagnostic calm",
                "forges the bedside clarity",
                "strengthens the clinical instinct",
                "prepares the steady hands",
                "sharpens the medical judgment"
            ),
            resolutions = listOf(
                "that a critical patient will depend on tomorrow.",
                "that turns anxious uncertainty into safe patient care.",
                "when an emergency ward looks to you for answers.",
                "that transforms textbook theory into real healing.",
                "long after university exams are behind you."
            )
        ),
        QuoteCategory.ANATOMY_PHYSIOLOGY to CompositionalFragments(
            openings = listOf(
                "Tracing every anatomical plane with patience",
                "Understanding physiological feedback from first principles",
                "Mastering the pathways of nerve and vessel",
                "Decoding how each organ guards homeostasis",
                "Studying structure and function side by side"
            ),
            bridges = listOf(
                "turns rote memorization into",
                "gives your clinical examination",
                "anchors your future surgical and medical decisions in",
                "replaces exam anxiety with",
                "builds an unshakable foundation of"
            ),
            resolutions = listOf(
                "three-dimensional bedside intuition.",
                "clear, mechanistic diagnostic sight.",
                "precision that protects every patient you touch.",
                "confidence when interpreting subtle clinical signs.",
                "lasting clinical competence."
            )
        ),
        QuoteCategory.PATHOLOGY_PHARMACOLOGY to CompositionalFragments(
            openings = listOf(
                "When you trace disease down to its cellular root,",
                "Mastering receptor mechanisms and pathological cascades",
                "Every morphological clue and drug interaction you learn",
                "Connecting Robbins pathology to rational therapeutics",
                "Understanding why a tissue fails and how a molecule heals"
            ),
            bridges = listOf(
                "transforms every future prescription into",
                "equips your clinical mind with",
                "elevates your bedside reasoning toward",
                "replaces trial-and-error with",
                "builds the diagnostic discipline for"
            ),
            resolutions = listOf(
                "deliberate, evidence-based patient care.",
                "safe, targeted intervention under pressure.",
                "accurate diagnosis before complications arise.",
                "thoughtful clinical stewardship.",
                "the art of healing with minimal harm."
            )
        ),
        QuoteCategory.CLINICAL_ROTATIONS to CompositionalFragments(
            openings = listOf(
                "Every patient history you listen to attentively",
                "Each physical sign you elicit at the bedside",
                "Standing observant through long morning ward rounds",
                "Correlating bedside findings with clinical physiology",
                "Examining every ward case with genuine curiosity"
            ),
            bridges = listOf(
                "trains your clinical senses to catch",
                "teaches what no textbook margin can capture:",
                "gradually shapes a student into",
                "sharpens your diagnostic ear for",
                "builds the quiet bedside confidence of"
            ),
            resolutions = listOf(
                "the subtle truth of human illness.",
                "a physician who sees the whole patient.",
                "the early warning signs that save lives.",
                "sound, compassionate clinical judgment.",
                "a dependable clinician under ward pressure."
            )
        ),
        QuoteCategory.VIVA_EXAMS to CompositionalFragments(
            openings = listOf(
                "Rehearsing your clinical cases aloud before the viva",
                "Organizing your differential diagnosis from first principles",
                "Approaching every examination table like a bedside consult",
                "Building structured recall through steady revision",
                "Meeting tough viva questions with calm honesty"
            ),
            bridges = listOf(
                "turns examination pressure into",
                "anchors your voice in",
                "proves that daily preparation creates",
                "replaces nervous hesitation with",
                "demonstrates the quiet poise of"
            ),
            resolutions = listOf(
                "clear, structured medical reasoning.",
                "the composure of a safe future clinician.",
                "competence that outlasts any single exam.",
                "diagnostic clarity when every second counts.",
                "a mind trained for real clinical responsibility."
            )
        ),
        QuoteCategory.NEET_PG_INI_CET to CompositionalFragments(
            openings = listOf(
                "Every clinical vignette you analyze during PG prep",
                "Reviewing each grand-test mistake with honest curiosity",
                "Consistent daily revision across high-yield subjects",
                "Linking basic science mechanisms to clinical next steps",
                "Protecting your daily MCQ and revision rhythm"
            ),
            bridges = listOf(
                "compounds quietly into",
                "builds the rapid pattern recognition for",
                "closes the gap between where you are and",
                "transforms entrance preparation into",
                "forges both exam-day composure and"
            ),
            resolutions = listOf(
                "decisive performance in NEET-PG and INI-CET.",
                "the residency seat your hard work deserves.",
                "first-year residency readiness.",
                "unshakeable clinical problem-solving.",
                "long-term mastery of clinical medicine."
            )
        ),
        QuoteCategory.DISCIPLINE_CONSISTENCY to CompositionalFragments(
            openings = listOf(
                "Opening your notes when motivation is low",
                "Protecting two distraction-free hours every evening",
                "Small, unglamorous revision sessions repeated daily",
                "Choosing steady study over fleeting comfort",
                "Honoring your daily study schedule without excuses"
            ),
            bridges = listOf(
                "accumulates silently into",
                "is the true architecture behind",
                "separates temporary effort from",
                "turns overwhelming medical syllabi into",
                "forges the lifelong professional habit of"
            ),
            resolutions = listOf(
                "extraordinary clinical reliability.",
                "command over the most demanding subjects.",
                "calm readiness on exam morning and night duty.",
                "deep, unhurried medical mastery.",
                "a physician colleagues and patients can trust."
            )
        ),
        QuoteCategory.FAILURE_COMEBACKS to CompositionalFragments(
            openings = listOf(
                "A tough viva or lower-than-hoped mock score",
                "Returning to your desk after an exhausting setback",
                "Every clinical blind spot uncovered by a mistake",
                "Rebuilding your study rhythm after a difficult week",
                "Refusing to let a hard semester define your potential"
            ),
            bridges = listOf(
                "is not a verdict, but",
                "becomes the turning point toward",
                "teaches the diagnostic humility and",
                "forges a deeper, steadier",
                "sharpens your preparation into"
            ),
            resolutions = listOf(
                "a stronger, wiser clinical comeback.",
                "resilience that every great doctor carries.",
                "mastery that easy success never teaches.",
                "unshakeable grit for the journey ahead.",
                "safe, humble, and attentive medical practice."
            )
        ),
        QuoteCategory.BECOMING_A_DOCTOR to CompositionalFragments(
            openings = listOf(
                "Each step from the lecture theatre to the hospital ward",
                "Learning to carry clinical responsibility with calm humility",
                "Every night you spend mastering the craft of medicine",
                "Growing from an uncertain student into a steady intern",
                "Honoring both the science and the duty of the white coat"
            ),
            bridges = listOf(
                "shapes you into the clinician",
                "builds the quiet authority",
                "prepares your mind and heart for",
                "bridges the distance between",
                "earns the sacred privilege of"
            ),
            resolutions = listOf(
                "who brings calm to someone's hardest hour.",
                "that patients trust when life feels fragile.",
                "the moment the ward looks to you for leadership.",
                "medical student effort and physician competence.",
                "caring for human lives with skill and grace."
            )
        ),
        QuoteCategory.PATIENT_CARE_COMPASSION to CompositionalFragments(
            openings = listOf(
                "Pausing to listen to a frightened patient's story",
                "Pairing rigorous clinical science with genuine bedside warmth",
                "Remembering the family waiting outside the ward doors",
                "Treating every patient chart as a human life in trust",
                "Bringing patience and dignity to every bedside encounter"
            ),
            bridges = listOf(
                "reminds you why your hardest study nights",
                "turns technical medical knowledge into",
                "is the clearest measure of",
                "anchors the noblest tradition of",
                "fulfills the deepest promise of"
            ),
            resolutions = listOf(
                "truly matter in the real world.",
                "healing that reaches both body and spirit.",
                "a complete and compassionate physician.",
                "medicine practiced with humanity.",
                "the white coat you worked so hard to wear."
            )
        )
    )

    data class GeneratedOfflineQuote(
        val text: String,
        val category: QuoteCategory,
        val normalizedHash: String
    )

    /**
     * Generates a validated, non-duplicate offline quote for one of the requested categories.
     */
    fun generateUniqueOfflineQuote(
        preferredCategories: Set<QuoteCategory>,
        existingHashes: Set<String>,
        recentQuoteTexts: List<String>,
        allowExtendedLength: Boolean = false,
        random: Random = Random.Default
    ): GeneratedOfflineQuote {
        val categories = if (preferredCategories.isEmpty()) {
            QuoteCategory.entries
        } else {
            preferredCategories.toList()
        }

        // First: gather candidate pool mixing curated and freshly synthesized compositional quotes
        val candidates = mutableListOf<Pair<QuoteCategory, String>>()

        for (cat in categories.shuffled(random)) {
            val curated = curatedByCategory[cat].orEmpty().shuffled(random)
            for (q in curated) {
                candidates.add(cat to q)
            }
            val comp = compositionalByCategory[cat]
            if (comp != null) {
                val openings = comp.openings.shuffled(random)
                val bridges = comp.bridges.shuffled(random)
                val resolutions = comp.resolutions.shuffled(random)
                for (o in openings) {
                    for (b in bridges) {
                        for (r in resolutions) {
                            candidates.add(cat to "$o $b $r")
                        }
                    }
                }
            }
        }

        candidates.shuffle(random)

        // Pass 1: Strict validation + strict duplicate & similarity avoidance
        for ((cat, candidateText) in candidates) {
            val validation = QuoteValidator.validateStructure(candidateText, allowExtendedLength)
            if (!validation.isValid) continue
            if (!QuoteValidator.isDuplicateOrTooSimilar(
                    validation.cleanedText,
                    existingHashes,
                    recentQuoteTexts
                )
            ) {
                return GeneratedOfflineQuote(
                    text = validation.cleanedText,
                    category = cat,
                    normalizedHash = validation.normalizedHash
                )
            }
        }

        // Pass 2: If history is very large and similarity threshold filtered everything,
        // require exact normalizedHash non-collision only
        for ((cat, candidateText) in candidates) {
            val validation = QuoteValidator.validateStructure(candidateText, allowExtendedLength)
            if (validation.isValid && validation.normalizedHash !in existingHashes) {
                return GeneratedOfflineQuote(
                    text = validation.cleanedText,
                    category = cat,
                    normalizedHash = validation.normalizedHash
                )
            }
        }

        // Pass 3: Fallback if every single permutation has been exhausted
        val fallbackCategory = categories.random(random)
        val fallbackText = curatedByCategory[fallbackCategory]?.random(random)
            ?: "Clinical competence is built quietly in the hours when nobody is applauding your discipline."
        return GeneratedOfflineQuote(
            text = fallbackText,
            category = fallbackCategory,
            normalizedHash = QuoteValidator.computeNormalizedHash(fallbackText)
        )
    }
}
