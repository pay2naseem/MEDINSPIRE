# MedInspire Release ProGuard / R8 Configuration
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations

# Keep Widget Providers & Boot Receiver
-keep class com.medinspire.app.widget.** { *; }

# Keep Room Entities & DAOs
-keep class com.medinspire.app.data.local.** { *; }

# Keep HTTPS DTO serialization models
-keep class com.medinspire.app.data.remote.** { *; }
