# MedInspire — Medical Motivation Widget (Android App & Home-Screen Widget)

**MedInspire** is a native Android application and home-screen widget built for **MBBS students, interns, postgraduate medical aspirants (NEET-PG / INI-CET), and resident doctors**.

Its primary feature is a native **Android AppWidget (`RemoteViews`)** that sits directly on the Android home screen in **2×2 (Compact)**, **4×2 (Standard Adaptive)**, and **4×3 (Editorial)** cell layouts, delivering original medical motivational quotes with one-tap home-screen refresh, local SQLite/Room persistence, duplicate/similarity rejection, and optional HTTPS AI backend integration.

## Quick Download & Installation

- **Pre-built Debug APK**: Download [`releases/MedInspire-debug.apk`](releases/MedInspire-debug.apk) directly from this repository (or from the **Actions / Releases** tab) and install on any Android 8.0+ (API 26–35) device:
  ```bash
  adb install -r releases/MedInspire-debug.apk
  ```

## How to Push This Repository to GitHub

### Option 1: Upload Directly on GitHub Web UI

1. Create a new repository on GitHub named **`MedInspire`**.
2. Extract `MedInspire-GitHub-Repository.zip` on your computer.
3. Upload the extracted files (including `.github/`, `app/`, `backend/`, `gradle/`, `releases/`, `.gitignore`, `build.gradle.kts`, `settings.gradle.kts`, and `README.md`) to your repository and commit to `main`.
4. GitHub Actions (`.github/workflows/android-ci.yml`) will automatically run unit tests and build the APK on every push.

### Option 2: Push via Git CLI

```bash
unzip MedInspire-GitHub-Repository.zip -d MedInspire
cd MedInspire
git init -b main
git add .
git commit -m "Initial commit: MedInspire Android App & Home-Screen Widget"
git remote add origin https://github.com/<your-username>/MedInspire.git
git push -u origin main
```

## 1. Architecture & Key Capabilities

| Layer | Implementation | Key Responsibilities |
| :--- | :--- | :--- |
| **Home-Screen Widget (`AppWidgetProvider`)** | `MedInspireWidgetProvider`, `MedInspireCompactWidgetProvider` (`2×2`), `MedInspireLargeWidgetProvider` (`4×3`), `WidgetRestoreReceiver` | Native `RemoteViews` rendering, responsive layout switching (`onAppWidgetOptionsChanged`), dynamic typography scaling (`11.5sp`–`18sp`), explicit refresh button & tap-on-quote `PendingIntent` broadcasts, loading indicator while preserving current quote, and reboot restoration (`BOOT_COMPLETED` / `MY_PACKAGE_REPLACED`). |
| **Main Application UI** | `MainActivity`, `MedInspireViewModel`, `MedInspireTheme` | Live hero quote card, source mode badge (`Online AI` vs `Offline Mode`), `↻ New Quote`, `Copy`, `☆ Save`, `Share`, `＋ Add Widget to Home Screen` (`AppWidgetManager.requestPinAppWidget`), interactive `2×2`/`4×2`/`4×3` widget preview, category filter chips, Favorites tab, History tab with `Clear History`, and Settings tab. |
| **Quote Uniqueness & Validation Engine** | `QuoteValidator` | Strips formatting artifacts, enforces word-count bounds (`6–28` words standard; up to `36` words for `4×3`), blocks false historical/celebrity doctor attributions (Osler, Hippocrates, Gawande, Kalanithi, Charaka, Sushruta, etc.), computes canonical SHA-256 normalized hashes, and rejects near-duplicates via **Token Jaccard Similarity** (`>= 0.60`) and **Normalized Levenshtein Similarity** (`>= 0.72`). |
| **Local Persistence** | `MedInspireDatabase`, `QuoteDao`, `QuoteEntity` (Room SQLite) & `UserPreferencesRepository` (DataStore) | Stores quote text, timestamp, category, source mode (`AI_ONLINE` vs `OFFLINE_ENGINE`), favorite status, and unique indexed `normalized_hash`. Retains favorites permanently and prunes non-favorite history beyond 400 entries. |
| **Honest Offline Fallback Engine** | `OfflineQuoteEngine` | Works 100% offline with zero network dependency. Combines **Curated MedInspire Originals** across all 10 MBBS categories with a **Compositional Medical Quote Synthesizer** capable of generating 2,500+ unique, non-cliché medical reflections, filtered against local history. Accurately labeled as `Offline Mode`. |
| **Secure HTTPS AI Integration** | `AiQuoteService` + `backend/server.js` | Zero hardcoded API keys in the APK or source code. Connects over HTTPS to a configurable backend endpoint (`POST /v1/quotes/generate`) with randomized specialty/tone/style parameters, client-side rate limiting (max 6 requests/min), and automatic offline fallback on network failure. |
| **Scheduled Background Refresh** | `WidgetRefreshWorker` (WorkManager) | Optional battery-safe periodic background widget updates (`PeriodicWorkRequest`, default 6 hours) without any permanent foreground/background service. |

## 2. Supported MBBS & Medical Categories

1. **MBBS Motivation** (`mbbs_motivation`) — Daily purpose and perspective across the MBBS journey.
2. **Anatomy and Physiology** (`anatomy_physiology`) — Dissection hall patience, physiological mechanisms, and structural mastery.
3. **Pathology and Pharmacology** (`pathology_pharmacology`) — Cellular injury, disease mechanisms, and rational therapeutics.
4. **Clinical Rotations** (`clinical_rotations`) — Bedside history taking, physical signs, ward rounds, and clinical acumen.
5. **Viva and University Exams** (`viva_exams`) — Composure under OSCE, long-case, and professional examination scrutiny.
6. **NEET-PG and INI-CET** (`neet_pg_ini_cet`) — Endurance for grand tests, clinical vignettes, and postgraduate entrance prep.
7. **Discipline and Consistency** (`discipline_consistency`) — Quiet daily study habits that compound into clinical reliability.
8. **Failure and Comebacks** (`failure_comebacks`) — Turning rough viva rounds, low mock scores, and fatigue into growth.
9. **Becoming a Doctor** (`becoming_a_doctor`) — Evolving from an anxious student into a steady, trustworthy clinician.
10. **Patient Care and Compassion** (`patient_care_compassion`) — Remembering the human life and family behind every chart and lab value.

## 3. Repository Structure

```text
MedInspire/
├── .github/
│   ├── PULL_REQUEST_TEMPLATE.md
│   └── workflows/
│       └── android-ci.yml                     # GitHub Actions CI/CD (Unit tests + APK build + Release)
├── .gitignore                                 # Excludes build outputs, .gradle, and keystores
├── LICENSE                                    # MIT License
├── CONTRIBUTING.md                            # Contributor guide
├── README.md                                  # Architecture & deployment guide
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradlew                                    # POSIX Gradle wrapper script
├── gradlew.bat                                # Windows Gradle wrapper script
├── keystore.properties.example                # Template for signed release APK configuration
├── gradle/
│   ├── libs.versions.toml
│   └── wrapper/
│       └── gradle-wrapper.properties
├── releases/
│   └── MedInspire-debug.apk                   # Pre-built, V1+V2 signed installable Debug APK
├── backend/
│   ├── server.js                              # Optional Node.js HTTPS AI proxy server
│   ├── package.json
│   ├── Dockerfile
│   └── .env.example
└── app/
    ├── build.gradle.kts                       # Debug & Release signing configurations
    ├── proguard-rules.pro                     # R8 / ProGuard rules for Release APK
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml            # App, 3 Widget Receivers (2x2, 4x2, 4x3), Boot Receiver
        │   ├── java/com/medinspire/app/
        │   │   ├── MainActivity.kt
        │   │   ├── domain/
        │   │   │   ├── model/Quote.kt
        │   │   │   ├── model/QuoteCategory.kt
        │   │   │   └── validation/QuoteValidator.kt
        │   │   ├── data/
        │   │   │   ├── local/QuoteEntity.kt
        │   │   │   ├── local/QuoteDao.kt
        │   │   │   ├── local/MedInspireDatabase.kt
        │   │   │   ├── offline/OfflineQuoteEngine.kt
        │   │   │   ├── preferences/UserPreferencesRepository.kt
        │   │   │   ├── remote/AiQuoteService.kt
        │   │   │   └── repository/QuoteRepository.kt
        │   │   ├── ui/
        │   │   │   ├── MedInspireViewModel.kt
        │   │   │   └── theme/Theme.kt
        │   │   └── widget/
        │   │       ├── MedInspireWidgetProvider.kt
        │   │       ├── MedInspireCompactWidgetProvider.kt
        │   │       ├── MedInspireLargeWidgetProvider.kt
        │   │       ├── WidgetRestoreReceiver.kt
        │   │       └── WidgetRefreshWorker.kt
        │   └── res/
        │       ├── drawable/
        │       ├── drawable-nodpi/
        │       ├── layout/
        │       ├── mipmap-mdpi/ .. mipmap-xxxhdpi/
        │       ├── values/
        │       └── xml/
        └── test/java/com/medinspire/app/
            └── QuoteValidatorAndUniquenessTest.kt
```

## 4. Documented AI Backend Contract (`POST /v1/quotes/generate`)

No API keys are embedded inside the Android app. When an HTTPS endpoint is configured in **Settings -> Secure AI Backend Configuration**, the app sends:

### Request (`POST /v1/quotes/generate`)

```json
{
  "categoryId": "clinical_rotations",
  "categoryName": "Clinical Rotations",
  "specialty": "Internal Medicine Ward",
  "emotionalTone": "calm and resolute",
  "writingStyle": "concise clinical aphorism",
  "targetWordRange": "8-22 words",
  "attemptNumber": 1,
  "avoidNormalizedHashes": [
    "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"
  ]
}
```

### Response (`200 OK`)

```json
{
  "quote": "A thorough history taken with patience often reveals what an expensive scan misses.",
  "categoryName": "Clinical Rotations",
  "attribution": "MedInspire Original",
  "sourceMode": "AI_ONLINE"
}
```
